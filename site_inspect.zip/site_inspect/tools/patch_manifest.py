import pathlib
import re

path = pathlib.Path("android/app/src/main/AndroidManifest.xml")
text = path.read_text()

permissions = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_MEDIA_LOCATION",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
]
added = "".join(
    f'    <uses-permission android:name="{p}"/>\n'
    for p in permissions
    if p not in text
)
added += '    <uses-feature android:name="android.hardware.camera" android:required="false"/>\n'
text = text.replace("<application", added + "    <application", 1)

# Speech recognition needs this package-visibility entry on Android 11+.
speech = '<intent><action android:name="android.speech.RecognitionService"/></intent>'
if "android.speech.RecognitionService" not in text:
    if "<queries>" in text:
        text = text.replace("<queries>", "<queries>\n        " + speech, 1)
    else:
        text = text.replace("</manifest>", "    <queries>\n        " + speech + "\n    </queries>\n</manifest>", 1)

text = re.sub(r'android:label="[^"]*"', 'android:label="Site Inspect"', text, count=1)

path.write_text(text)
print("Manifest patched")
