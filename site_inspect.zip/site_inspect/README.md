# Site Inspect

Construction inspection and progress-report app (Android, Flutter). Offline first.

## Get the APK from GitHub

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, then **Build Android APK**, then **Run workflow** (it also runs on every push to `main`).
3. When it finishes, open the run and download the **site-inspect-apk** artifact. Unzip it and install `app-release.apk` on your phone (allow "install unknown apps" for your browser / files app).

The workflow generates the Android wrapper (`flutter create`) and adds the permissions the app needs (internet, location, camera, microphone, speech recognition) through `tools/patch_manifest.py`, so only `lib/` and `pubspec.yaml` live in the repo.

If the build fails, open the failed run, copy the red error lines and send them to Claude to fix.

## Features

**Projects and progress**
- Unlimited projects (name, location, client); search them from the home screen.
- Overall progress log with a date above each percentage (editable).
- Each trade has its own dated progress log. Trades are free-form (quick-pick list or your own).
- Optional **weighted overall %**: give each trade a weight and the overall percentage is calculated for you.
- **Planned vs actual S-curve** with ahead / behind variance.

**Inspections**
- Date, status (presets or your own), inspector name, role (Inspector / Engineer / Architect / custom), company, free notes.
- **Checklists**: reusable templates (Pass / Fail / N/A plus a remark per item), or one-off items.
- **Sign-off**: finger signatures for inspector, contractor and client. The inspector's signature can be saved and reused.
- **Voice notes**: tap the microphone to dictate into notes and descriptions.

**Photos**
- **In-app camera** that stays open for several shots in a row. Each photo is stamped with date/time, project name (optional), street address and GPS. The untouched original is kept too.
- Gallery photos keep their own date / GPS when they have them.
- Draw arrows, circles, pen, text and pins on any photo (non-destructive, shown in the PDF).

**Keyplans**
- Upload an image or a multi-page PDF (choose pages), then add numbered pins, arrows, circles, pen, text, boxes and lines. Move, resize, recolour, change line weight / size, undo.

**Punch list**
- Defects with number, description, location, trade, responsible party, due date, status (Open / Fixed / Verified), before and after photos, and a link to a keyplan pin. Overdue items are flagged.

**Daily site log**
- Date, weather (type it or fetch automatically), temperature, manpower by trade, equipment, delays, notes.

**Search and reports**
- Search inspections by text, status, trade and date range.
- **PDF report**: branded cover page (logo, company, licence no., report number, revision), headers and footers, progress tables, S-curve, inspections with checklists, photos with map links, signatures, punch list, site logs, marked-up keyplans.
- **Excel report**: Summary, Trade Progress, Inspections, Checklists, Punch List, Site Log, Photos.
- Optional date range, so a report can cover only a period.
- Reports are plain white pages; the blueprint look is for the app interface only.

**Safety**
- **App lock** with a 4 to 6 digit PIN (Settings).
- Backup / restore to a single `.sibackup` file; the home screen reminds you if the last backup is over 7 days old.

## Good to know

- Everything is stored on the phone. Uninstalling the app deletes it, so back up first.
- The PIN hides the app only. Backup files are not encrypted, and a forgotten PIN cannot be recovered.
- Fingerprint unlock and automatic Google Drive / OneDrive sync are not included yet. Backups go to Drive / OneDrive through the share menu.
- Street address and automatic weather need an internet connection; without it, the photo shows GPS only and weather can be typed.
- PDF reports use the standard PDF font, so characters outside Latin-1 (e.g. emoji) print as `?`.
- The app locks again after 2 minutes in the background. Long visits to the phone camera, gallery or share sheet count as background time.
