import 'package:flutter/material.dart';

import '../models.dart';
import '../photo_service.dart';
import '../store.dart';
import '../theme.dart';
import '../weather.dart';
import '../widgets.dart';

const kManpowerQuick = ['Foreman', 'Laborer', 'Mason', 'Carpenter', 'Electrician', 'Plumber', 'Welder', 'Engineer'];

// ================================================================= tab

class SiteLogTab extends StatefulWidget {
  const SiteLogTab({super.key, required this.project, required this.onChanged});
  final Project project;
  final VoidCallback onChanged;

  @override
  State<SiteLogTab> createState() => _SiteLogTabState();
}

class _SiteLogTabState extends State<SiteLogTab> {
  Project get pr => widget.project;

  Future<void> _open(SiteLog l) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => SiteLogScreen(log: l)));
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final list = [...pr.logs]..sort((a, b) => b.date.compareTo(a.date));
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('NEW DAILY SITE LOG'),
            onPressed: () async {
              final l = SiteLog(date: DateTime.now());
              pr.logs.add(l);
              await Store.i.save();
              if (mounted) await _open(l);
            },
          ),
        ),
        const SizedBox(height: 12),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('Record weather, manpower, equipment and delays for each day on site.', textAlign: TextAlign.center),
          ),
        for (final l in list)
          BpCard(
            onTap: () => _open(l),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.event, size: 16, color: kCyan),
                    const SizedBox(width: 6),
                    Text(fmtDate(l.date), style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
                    const Spacer(),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.delete_outline, size: 20),
                      onPressed: () async {
                        if (await confirm(context, 'Delete log', 'Delete the site log of ${fmtDate(l.date)}?')) {
                          pr.logs.remove(l);
                          widget.onChanged();
                        }
                      },
                    ),
                  ],
                ),
                Text(
                  [
                    if (l.weather.isNotEmpty) l.weather,
                    if (l.temp.isNotEmpty) '${l.temp}°C',
                    'Manpower: ${l.totalManpower}',
                  ].join('  |  '),
                  style: const TextStyle(fontSize: 12, color: kLine),
                ),
                if (l.delays.trim().isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('Delays: ${l.delays.trim()}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

// ============================================================== detail

class SiteLogScreen extends StatefulWidget {
  const SiteLogScreen({super.key, required this.log});
  final SiteLog log;

  @override
  State<SiteLogScreen> createState() => _SiteLogScreenState();
}

class _SiteLogScreenState extends State<SiteLogScreen> {
  SiteLog get log => widget.log;
  late final _temp = TextEditingController(text: log.temp);
  late final _equip = TextEditingController(text: log.equipment);
  late final _delays = TextEditingController(text: log.delays);
  late final _notes = TextEditingController(text: log.notes);
  int _wKey = 0;

  @override
  void dispose() {
    _temp.dispose();
    _equip.dispose();
    _delays.dispose();
    _notes.dispose();
    Store.i.save();
    super.dispose();
  }

  Future<void> _autoWeather() async {
    final w = await runWithLoader<({String text, double temp})?>(context, 'Getting weather…', () async {
      final p = await PhotoService.currentPosition();
      if (p == null) return null;
      return fetchWeather(p.latitude, p.longitude);
    });
    if (!mounted) return;
    if (w == null) {
      toast(context, 'Could not get the weather (needs GPS and internet)');
      return;
    }
    setState(() {
      log.weather = w.text;
      log.temp = w.temp.toStringAsFixed(0);
      _temp.text = log.temp;
      _wKey++;
    });
    Store.i.saveSoon();
  }

  void _addWorker(String label) {
    final i = log.manpower.indexWhere((m) => m.label == label);
    setState(() {
      if (i >= 0) {
        log.manpower[i].count += 1;
      } else {
        log.manpower.add(ManpowerItem(label: label));
      }
    });
    Store.i.saveSoon();
  }

  Widget _field(String label, TextEditingController c, void Function(String) set) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: TextField(
              controller: c,
              minLines: 2,
              maxLines: 8,
              textCapitalization: TextCapitalization.sentences,
              decoration: deco(label),
              onChanged: (v) {
                set(v);
                Store.i.saveSoon();
              },
            ),
          ),
          MicButton(
            controller: c,
            onText: (v) {
              set(v);
              Store.i.saveSoon();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BpScaffold(
      title: 'Daily site log',
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Date and weather'),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.event),
                    label: Text('Date: ${fmtDate(log.date)}'),
                    onPressed: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: log.date,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (d != null) {
                        setState(() => log.date = d);
                        Store.i.saveSoon();
                      }
                    },
                  ),
                ),
                const SizedBox(height: 12),
                ChipPicker(
                  key: ValueKey('w$_wKey'),
                  presets: const ['Sunny', 'Cloudy', 'Rainy', 'Stormy'],
                  value: log.weather,
                  customHint: 'Describe the weather',
                  onChanged: (v) {
                    log.weather = v;
                    Store.i.saveSoon();
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(
                      width: 120,
                      child: TextField(
                        controller: _temp,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: deco('Temp °C'),
                        onChanged: (v) {
                          log.temp = v.trim();
                          Store.i.saveSoon();
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _autoWeather,
                        icon: const Icon(Icons.cloud_download),
                        label: const Text('AUTO (GPS)'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BpLabel('Manpower on site  |  total ${log.totalManpower}'),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final q in kManpowerQuick)
                      ActionChip(label: Text('+ $q', style: const TextStyle(fontSize: 12)), onPressed: () => _addWorker(q)),
                    ActionChip(
                      label: const Text('+ Other…', style: TextStyle(fontSize: 12)),
                      onPressed: () async {
                        final n = await askText(context, 'Add manpower type', hint: 'e.g. Surveyor');
                        if (n != null && n.isNotEmpty) _addWorker(n);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                for (final m in log.manpower)
                  Row(
                    children: [
                      Expanded(child: Text(m.label)),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: () {
                          setState(() {
                            if (m.count > 1) {
                              m.count -= 1;
                            } else {
                              log.manpower.remove(m);
                            }
                          });
                          Store.i.saveSoon();
                        },
                      ),
                      SizedBox(width: 30, child: Text('${m.count}', textAlign: TextAlign.center, style: const TextStyle(fontFamily: kMono, fontSize: 16))),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () {
                          setState(() => m.count += 1);
                          Store.i.saveSoon();
                        },
                      ),
                    ],
                  ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Site conditions'),
                _field('Equipment on site', _equip, (v) => log.equipment = v),
                _field('Delays / issues', _delays, (v) => log.delays = v),
                _field('Notes', _notes, (v) => log.notes = v),
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
