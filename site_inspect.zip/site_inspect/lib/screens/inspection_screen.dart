import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../markup_painter.dart';
import '../models.dart';
import '../photo_service.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'camera_screen.dart';
import 'keyplan_screen.dart';
import 'signature_screen.dart';

const kStatuses = ['Pending', 'In progress', 'Passed', 'Failed', 'Needs rework'];
const kRoles = ['Inspector', 'Engineer', 'Architect'];

Color checkColor(String r) {
  switch (r) {
    case 'Pass':
      return kGood;
    case 'Fail':
      return kBad;
    default:
      return kCyan;
  }
}

class InspectionScreen extends StatefulWidget {
  const InspectionScreen({super.key, required this.project, required this.trade, required this.inspection});
  final Project project;
  final Trade trade;
  final Inspection inspection;

  @override
  State<InspectionScreen> createState() => _InspectionScreenState();
}

class _InspectionScreenState extends State<InspectionScreen> {
  Inspection get ins => widget.inspection;
  late final TextEditingController _name = TextEditingController(text: ins.inspectorName);
  late final TextEditingController _company = TextEditingController(text: ins.company);
  late final TextEditingController _notes = TextEditingController(text: ins.notes);
  late final TextEditingController _conName = TextEditingController(text: ins.sigContractor.name);
  late final TextEditingController _cliName = TextEditingController(text: ins.sigClient.name);

  @override
  void dispose() {
    _name.dispose();
    _company.dispose();
    _notes.dispose();
    _conName.dispose();
    _cliName.dispose();
    Store.i.save();
    super.dispose();
  }

  void _remember() {
    final s = Store.i.settings;
    s.lastName = ins.inspectorName;
    s.lastRole = ins.role;
    s.lastCompany = ins.company;
    Store.i.saveSoon();
  }

  String? get _stampName => Store.i.settings.stampProject ? widget.project.name : null;

  // ----------------------------------------------------------------- photos

  Future<void> _takePhoto() async {
    final res = await Navigator.push<List<PhotoItem>>(
      context,
      MaterialPageRoute(builder: (_) => CameraScreen(projectName: _stampName)),
    );
    if (!mounted) return;
    if (res == null) {
      await _systemCamera();
      return;
    }
    if (res.isEmpty) return;
    ins.photos.addAll(res);
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<void> _systemCamera() async {
    final position = PhotoService.currentPosition();
    final x = await PhotoService.openCamera();
    if (x == null || !mounted) return;
    final item = await runWithLoader(
      context,
      'Stamping photo…',
      () => PhotoService.processCapture(x, position: position, projectName: _stampName),
    );
    ins.photos.add(item);
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<void> _fromGallery() async {
    final items = await runWithLoader(context, 'Importing photos…', PhotoService.importFromGallery);
    if (items.isEmpty) return;
    ins.photos.addAll(items);
    await Store.i.save();
    if (mounted) setState(() {});
  }

  // -------------------------------------------------------------- checklist

  Future<void> _addChecklist() async {
    final ts = Store.i.templates;
    final t = await showDialog<ChecklistTemplate>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('ADD CHECKLIST', style: TextStyle(fontFamily: kMono, fontSize: 16)),
        children: [
          if (ts.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No templates yet. Use "+ ITEM" or create templates from the home menu.'),
            ),
          for (final t in ts)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, t),
              child: Text('${t.name}  (${t.items.length} items)'),
            ),
        ],
      ),
    );
    if (t == null) return;
    setState(() => ins.checklist.addAll(t.items.map((s) => CheckItem(text: s))));
    Store.i.saveSoon();
  }

  Future<void> _addItem() async {
    final s = await askText(context, 'Checklist item', hint: 'What to check', multiline: true);
    if (s == null || s.isEmpty) return;
    setState(() => ins.checklist.add(CheckItem(text: s)));
    Store.i.saveSoon();
  }

  Future<void> _saveTemplate() async {
    if (ins.checklist.isEmpty) return;
    final n = await askText(context, 'Save as template', hint: 'Template name', initial: widget.trade.name);
    if (n == null || n.isEmpty) return;
    Store.i.templates.add(ChecklistTemplate(name: n, items: ins.checklist.map((e) => e.text).toList()));
    await Store.i.save();
    if (mounted) toast(context, 'Template saved');
  }

  Widget _checklistCard() {
    final cl = ins.checklist;
    final pass = cl.where((e) => e.result == 'Pass').length;
    final fail = cl.where((e) => e.result == 'Fail').length;
    return BpCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BpLabel('Checklist${cl.isEmpty ? '' : '  |  $pass pass, $fail fail, ${cl.length} items'}'),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              FilledButton.icon(onPressed: _addChecklist, icon: const Icon(Icons.checklist), label: const Text('FROM TEMPLATE')),
              OutlinedButton.icon(onPressed: _addItem, icon: const Icon(Icons.add), label: const Text('ITEM')),
              if (cl.isNotEmpty)
                OutlinedButton.icon(onPressed: _saveTemplate, icon: const Icon(Icons.bookmark_add), label: const Text('SAVE AS TEMPLATE')),
            ],
          ),
          const SizedBox(height: 8),
          for (final item in cl)
            _CheckRow(
              key: ValueKey(item.id),
              item: item,
              onChanged: () {
                setState(() {});
                Store.i.saveSoon();
              },
              onDelete: () {
                setState(() => cl.remove(item));
                Store.i.saveSoon();
              },
            ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------- signatures

  Future<void> _sign(SignBlock b, String who) async {
    final res = await Navigator.push<(Uint8List, bool)>(
      context,
      MaterialPageRoute(builder: (_) => SignatureScreen(who: who, offerRemember: who == 'Inspector')),
    );
    if (res == null) return;
    if (b.file != null) await Store.i.deleteMedia(b.file!);
    b.file = await Store.i.addMediaBytes(res.$1, 'png');
    b.date = DateTime.now();
    if (res.$2) {
      final s = Store.i.settings;
      if (s.mySig != null) await Store.i.deleteMedia(s.mySig!);
      s.mySig = await Store.i.addMediaBytes(res.$1, 'png');
    }
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<void> _useSaved(SignBlock b) async {
    final saved = Store.i.settings.mySig;
    if (saved == null) return;
    final bytes = await File(Store.i.mediaPath(saved)).readAsBytes();
    if (b.file != null) await Store.i.deleteMedia(b.file!);
    b.file = await Store.i.addMediaBytes(bytes, 'png');
    b.date = DateTime.now();
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<void> _clearSig(SignBlock b) async {
    if (b.file != null) await Store.i.deleteMedia(b.file!);
    b.file = null;
    b.date = null;
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Widget _signBox(String who, SignBlock b, {TextEditingController? nameC}) {
    final hasSaved = who == 'Inspector' && Store.i.settings.mySig != null;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BpLabel(who),
          if (nameC != null) ...[
            TextField(
              controller: nameC,
              textCapitalization: TextCapitalization.words,
              decoration: deco('$who name'),
              onChanged: (v) {
                b.name = v.trim();
                Store.i.saveSoon();
              },
            ),
            const SizedBox(height: 8),
          ] else
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(ins.inspectorName.isEmpty ? '(enter your name above)' : ins.inspectorName),
            ),
          Container(
            height: 84,
            width: double.infinity,
            color: Colors.white,
            alignment: Alignment.center,
            child: b.file == null
                ? const Text('Not signed', style: TextStyle(color: Colors.black45))
                : Image.file(File(Store.i.mediaPath(b.file!)), fit: BoxFit.contain),
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: [
              FilledButton.icon(
                onPressed: () => _sign(b, who),
                icon: const Icon(Icons.draw),
                label: Text(b.file == null ? 'SIGN' : 'RE-SIGN'),
              ),
              if (hasSaved)
                OutlinedButton(onPressed: () => _useSaved(b), child: const Text('USE SAVED')),
              if (b.file != null)
                OutlinedButton(onPressed: () => _clearSig(b), child: const Text('CLEAR')),
            ],
          ),
          if (b.date != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('Signed ${fmtDateTime(b.date!)}', style: const TextStyle(fontSize: 11, color: kLine)),
            ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return BpScaffold(
      title: 'Inspection',
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BpLabel('${widget.trade.name} | inspection details'),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.event),
                    label: Text('Date: ${fmtDate(ins.date)}'),
                    onPressed: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: ins.date,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (d != null) {
                        setState(() => ins.date = d);
                        Store.i.saveSoon();
                      }
                    },
                  ),
                ),
                const SizedBox(height: 14),
                const BpLabel('Status'),
                ChipPicker(
                  presets: kStatuses,
                  value: ins.status,
                  customHint: 'Type your own status',
                  onChanged: (v) {
                    setState(() => ins.status = v.isEmpty ? 'Pending' : v);
                    Store.i.saveSoon();
                  },
                ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Inspected by'),
                TextField(
                  controller: _name,
                  textCapitalization: TextCapitalization.words,
                  decoration: deco('Full name'),
                  onChanged: (v) {
                    ins.inspectorName = v.trim();
                    _remember();
                  },
                ),
                const SizedBox(height: 12),
                const BpLabel('Role'),
                ChipPicker(
                  presets: kRoles,
                  value: ins.role,
                  customHint: 'Type your role / title',
                  onChanged: (v) {
                    ins.role = v;
                    _remember();
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _company,
                  textCapitalization: TextCapitalization.words,
                  decoration: deco('Company'),
                  onChanged: (v) {
                    ins.company = v.trim();
                    _remember();
                  },
                ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(child: BpLabel('Notes / remarks')),
                    MicButton(
                      controller: _notes,
                      onText: (v) {
                        ins.notes = v;
                        Store.i.saveSoon();
                      },
                    ),
                  ],
                ),
                TextField(
                  controller: _notes,
                  minLines: 4,
                  maxLines: 12,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: deco('Write or dictate: findings, issues, instructions…'),
                  onChanged: (v) {
                    ins.notes = v;
                    Store.i.saveSoon();
                  },
                ),
              ],
            ),
          ),
          _checklistCard(),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BpLabel('Photos (${ins.photos.length})'),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _takePhoto,
                        icon: const Icon(Icons.photo_camera),
                        label: const Text('CAMERA'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _fromGallery,
                        icon: const Icon(Icons.photo_library),
                        label: const Text('GALLERY'),
                      ),
                    ),
                  ],
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: const Text('Print project name on camera photos'),
                  subtitle: const Text('Date, time, address and GPS are always stamped.', style: TextStyle(fontSize: 11)),
                  value: Store.i.settings.stampProject,
                  onChanged: (v) {
                    setState(() => Store.i.settings.stampProject = v);
                    Store.i.saveSoon();
                  },
                ),
                LayoutBuilder(
                  builder: (context, cons) {
                    final w = (cons.maxWidth - 8) / 2;
                    return Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final ph in ins.photos)
                          SizedBox(
                            key: ValueKey(ph.id),
                            width: w,
                            child: _PhotoTile(
                              photo: ph,
                              onMarkup: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => KeyplanScreen(title: 'Photo markup', file: ph.file, markups: ph.markups),
                                  ),
                                );
                                Store.i.saveSoon();
                                if (mounted) setState(() {});
                              },
                              onDelete: () async {
                                if (await confirm(context, 'Delete photo', 'Remove this photo?')) {
                                  for (final f in ph.allFiles) {
                                    await Store.i.deleteMedia(f);
                                  }
                                  ins.photos.remove(ph);
                                  await Store.i.save();
                                  if (mounted) setState(() {});
                                }
                              },
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Sign-off'),
                _signBox('Inspector', ins.sigInspector),
                _signBox('Contractor', ins.sigContractor, nameC: _conName),
                _signBox('Client', ins.sigClient, nameC: _cliName),
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _CheckRow extends StatefulWidget {
  const _CheckRow({super.key, required this.item, required this.onChanged, required this.onDelete});
  final CheckItem item;
  final VoidCallback onChanged;
  final VoidCallback onDelete;

  @override
  State<_CheckRow> createState() => _CheckRowState();
}

class _CheckRowState extends State<_CheckRow> {
  late final TextEditingController _c = TextEditingController(text: widget.item.remark);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final it = widget.item;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(border: Border.all(color: kLine.withAlpha(90)), borderRadius: BorderRadius.circular(3)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(it.text, style: const TextStyle(fontWeight: FontWeight.w600))),
              IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.close, size: 18), onPressed: widget.onDelete),
            ],
          ),
          Wrap(
            spacing: 6,
            children: [
              for (final r in ['Pass', 'Fail', 'N/A'])
                ChoiceChip(
                  label: Text(r),
                  selected: it.result == r,
                  showCheckmark: false,
                  selectedColor: checkColor(r),
                  backgroundColor: kBlueDeep.withAlpha(200),
                  labelStyle: TextStyle(color: it.result == r ? Colors.black : kPaper, fontWeight: FontWeight.w600),
                  side: BorderSide(color: it.result == r ? checkColor(r) : kLine.withAlpha(150)),
                  onSelected: (_) {
                    it.result = it.result == r ? '' : r;
                    widget.onChanged();
                  },
                ),
            ],
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _c,
            style: const TextStyle(fontSize: 13),
            textCapitalization: TextCapitalization.sentences,
            decoration: deco('Remark'),
            onChanged: (v) {
              it.remark = v;
              Store.i.saveSoon();
            },
          ),
        ],
      ),
    );
  }
}

class _PhotoTile extends StatefulWidget {
  const _PhotoTile({required this.photo, required this.onDelete, required this.onMarkup});
  final PhotoItem photo;
  final VoidCallback onDelete;
  final VoidCallback onMarkup;

  @override
  State<_PhotoTile> createState() => _PhotoTileState();
}

class _PhotoTileState extends State<_PhotoTile> {
  late final TextEditingController _c = TextEditingController(text: widget.photo.caption);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ph = widget.photo;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            GestureDetector(
              onTap: () => showPhotoViewer(context, ph),
              child: AspectRatio(
                aspectRatio: 4 / 3,
                child: Image.file(File(Store.i.mediaPath(ph.file)), fit: BoxFit.cover, cacheWidth: 600),
              ),
            ),
            Positioned(
              top: 2,
              right: 2,
              child: Material(
                color: Colors.black54,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: widget.onDelete,
                  child: const Padding(padding: EdgeInsets.all(5), child: Icon(Icons.close, size: 16, color: Colors.white)),
                ),
              ),
            ),
            Positioned(
              bottom: 2,
              right: 2,
              child: Material(
                color: ph.markups.isEmpty ? Colors.black54 : kAccent,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: widget.onMarkup,
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Icon(Icons.draw, size: 16, color: ph.markups.isEmpty ? Colors.white : Colors.black),
                  ),
                ),
              ),
            ),
            if (ph.lat != null)
              const Positioned(left: 4, top: 4, child: Icon(Icons.place, size: 18, color: kAccent)),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          ph.takenAt == null ? 'No timestamp (gallery)' : fmtDateTime(ph.takenAt!),
          style: const TextStyle(fontSize: 10, color: kLine),
        ),
        if (ph.address.isNotEmpty) Text(ph.address, style: const TextStyle(fontSize: 10, color: kLine), maxLines: 2, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 4),
        TextField(
          controller: _c,
          style: const TextStyle(fontSize: 13),
          textCapitalization: TextCapitalization.sentences,
          decoration: deco('Caption'),
          onChanged: (v) {
            ph.caption = v;
            Store.i.saveSoon();
          },
        ),
      ],
    );
  }
}

void showPhotoViewer(BuildContext context, PhotoItem ph) {
  final info = [
    if (ph.takenAt != null) fmtDateTime(ph.takenAt!),
    if (ph.address.isNotEmpty) ph.address,
    if (ph.lat != null && ph.lng != null) '${ph.lat!.toStringAsFixed(6)}, ${ph.lng!.toStringAsFixed(6)}',
    if (ph.caption.isNotEmpty) ph.caption,
  ].join('\n');
  final Widget image = ph.markups.isEmpty
      ? Image.file(File(Store.i.mediaPath(ph.file)))
      : FutureBuilder<Uint8List?>(
          future: renderKeyplanPng(Store.i.mediaPath(ph.file), ph.markups, maxW: 2000),
          builder: (c, s) => s.data == null ? const Center(child: CircularProgressIndicator()) : Image.memory(s.data!),
        );
  showDialog<void>(
    context: context,
    builder: (ctx) => Dialog.fullscreen(
      backgroundColor: Colors.black,
      child: Stack(
        children: [
          Positioned.fill(child: InteractiveViewer(child: image)),
          Positioned(
            top: 8,
            left: 8,
            child: SafeArea(child: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(ctx))),
          ),
          if (info.isNotEmpty)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.all(12),
                child: SafeArea(top: false, child: Text(info, style: const TextStyle(color: Colors.white))),
              ),
            ),
        ],
      ),
    ),
  );
}
