import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class TemplatesScreen extends StatefulWidget {
  const TemplatesScreen({super.key});

  @override
  State<TemplatesScreen> createState() => _TemplatesScreenState();
}

class _TemplatesScreenState extends State<TemplatesScreen> {
  Future<void> _edit(ChecklistTemplate? existing) async {
    final name = TextEditingController(text: existing?.name ?? '');
    final items = TextEditingController(text: existing?.items.join('\n') ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(existing == null ? 'NEW TEMPLATE' : 'EDIT TEMPLATE', style: const TextStyle(fontFamily: kMono, fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, autofocus: true, textCapitalization: TextCapitalization.sentences, decoration: deco('Template name')),
              const SizedBox(height: 10),
              TextField(
                controller: items,
                minLines: 6,
                maxLines: 12,
                textCapitalization: TextCapitalization.sentences,
                decoration: deco('Checklist items', hint: 'One item per line'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    final list = items.text.split('\n').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
    if (existing == null) {
      Store.i.templates.add(ChecklistTemplate(name: name.text.trim(), items: list));
    } else {
      existing
        ..name = name.text.trim()
        ..items = list;
    }
    await Store.i.save();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final ts = Store.i.templates;
    return BpScaffold(
      title: 'Checklist templates',
      fab: FloatingActionButton.extended(
        onPressed: () => _edit(null),
        backgroundColor: kAccent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('NEW TEMPLATE', style: TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
        children: [
          const Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Text('Templates are reusable lists you can add to any inspection.', style: TextStyle(fontSize: 12, color: kLine)),
          ),
          if (ts.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No templates yet.', textAlign: TextAlign.center)),
          for (final t in ts)
            BpCard(
              onTap: () => _edit(t),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('${t.items.length} items', style: const TextStyle(fontSize: 12, color: kLine)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (await confirm(context, 'Delete template', 'Delete "${t.name}"? Inspections that already used it keep their items.')) {
                        ts.remove(t);
                        await Store.i.save();
                        if (mounted) setState(() {});
                      }
                    },
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
