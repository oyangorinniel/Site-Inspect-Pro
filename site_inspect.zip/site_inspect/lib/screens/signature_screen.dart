import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets.dart';

/// Finger-signature pad. Pops with (png bytes, rememberAsDefault).
class SignatureScreen extends StatefulWidget {
  const SignatureScreen({super.key, required this.who, this.offerRemember = false});
  final String who;
  final bool offerRemember;

  @override
  State<SignatureScreen> createState() => _SignatureScreenState();
}

class _SignatureScreenState extends State<SignatureScreen> {
  final List<List<Offset>> _strokes = [];
  bool _remember = false;
  Size _size = const Size(300, 120);

  Future<Uint8List> _render() async {
    const outW = 900.0;
    final sx = outW / _size.width;
    final outH = _size.height * sx;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    c.scale(sx);
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final s in _strokes) {
      if (s.length == 1) {
        c.drawCircle(s.first, 1.4, Paint()..color = Colors.black);
        continue;
      }
      final path = Path()..moveTo(s.first.dx, s.first.dy);
      for (final o in s.skip(1)) {
        path.lineTo(o.dx, o.dy);
      }
      c.drawPath(path, paint);
    }
    final im = await rec.endRecording().toImage(outW.round(), outH.round());
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
  }

  Future<void> _save() async {
    if (_strokes.isEmpty) {
      toast(context, 'Please sign first');
      return;
    }
    final bytes = await _render();
    if (mounted) Navigator.pop<(Uint8List, bool)>(context, (bytes, _remember));
  }

  @override
  Widget build(BuildContext context) {
    return BpScaffold(
      title: 'Sign: ${widget.who}',
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const BpLabel('Sign inside the box with your finger'),
          LayoutBuilder(
            builder: (context, cons) {
              final w = cons.maxWidth;
              final h = w / 2.5;
              _size = Size(w, h);
              return ClipRect(
                child: Container(
                  width: w,
                  height: h,
                  color: Colors.white,
                  child: GestureDetector(
                    onPanStart: (d) => setState(() => _strokes.add([d.localPosition])),
                    onPanUpdate: (d) {
                      if (_strokes.isEmpty) return;
                      setState(() => _strokes.last.add(d.localPosition));
                    },
                    child: CustomPaint(painter: _PadPainter(_strokes), size: Size(w, h)),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          if (widget.offerRemember)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Remember as my signature'),
              subtitle: const Text('Reuse it on future inspections with one tap.', style: TextStyle(fontSize: 11)),
              value: _remember,
              onChanged: (v) => setState(() => _remember = v),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => setState(_strokes.clear),
                  icon: const Icon(Icons.refresh),
                  label: const Text('CLEAR'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.check),
                  label: const Text('SAVE'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PadPainter extends CustomPainter {
  _PadPainter(this.strokes);
  final List<List<Offset>> strokes;

  @override
  void paint(Canvas canvas, Size size) {
    final guide = Paint()
      ..color = Colors.black26
      ..strokeWidth = 1;
    canvas.drawLine(Offset(12, size.height * 0.78), Offset(size.width - 12, size.height * 0.78), guide);
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final s in strokes) {
      if (s.length == 1) {
        canvas.drawCircle(s.first, 1.4, Paint()..color = Colors.black);
        continue;
      }
      final path = Path()..moveTo(s.first.dx, s.first.dy);
      for (final o in s.skip(1)) {
        path.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PadPainter old) => true;
}
