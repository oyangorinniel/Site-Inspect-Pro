import 'dart:io';

import 'package:flutter/material.dart';

import '../calc.dart';
import '../models.dart';
import '../photo_service.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'camera_screen.dart';
import 'inspection_screen.dart' show showPhotoViewer;

const kDefectStatuses = ['Open', 'Fixed', 'Verified'];

Color defectColor(String s) {
  switch (s) {
    case 'Open':
      return kBad;
    case 'Fixed':
      return kAccent;
    case 'Verified':
      return kGood;
    default:
      return kCyan;
  }
}

bool isOverdue(Defect d) =>
    d.due != null &&
    d.status != 'Fixed' &&
    d.status != 'Verified' &&
    dateOnly(d.due!).isBefore(dateOnly(DateTime.now()));

// ================================================================= tab

class DefectsTab extends StatefulWidget {
  const DefectsTab({super.key, required this.project, required this.onChanged});
  final Project project;
  final VoidCallback onChanged;

  @override
  State<DefectsTab> createState() => _DefectsTabState();
}

class _DefectsTabState extends State<DefectsTab> {
  String _filter = 'All';
  Project get pr => widget.project;

  Future<void> _new() async {
    pr.defectSeq += 1;
    final n = pr.defectSeq;
    final d = Defect(no: 'D-${n.toString().padLeft(3, '0')}');
    pr.defects.add(d);
    await Store.i.save();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => DefectScreen(project: pr, defect: d)));
    if (pr.defects.contains(d) &&
        d.title.trim().isEmpty &&
        d.desc.trim().isEmpty &&
        d.before == null &&
        d.after == null) {
      pr.defects.remove(d);
      if (pr.defectSeq == n) pr.defectSeq -= 1;
    }
    widget.onChanged();
  }

  Future<void> _open(Defect d) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => DefectScreen(project: pr, defect: d)));
    widget.onChanged();
  }

  Widget _stat(String label, int n, Color c) => Expanded(
        child: Column(
          children: [
            Text('$n', style: TextStyle(fontFamily: kMono, fontSize: 26, fontWeight: FontWeight.bold, color: c)),
            Text(label.toUpperCase(), style: const TextStyle(fontSize: 11, fontFamily: kMono)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final all = [...pr.defects]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final shown = _filter == 'All' ? all : all.where((d) => d.status == _filter).toList();
    int count(String s) => pr.defects.where((d) => d.status == s).length;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: _new,
            icon: const Icon(Icons.add),
            label: const Text('NEW DEFECT / PUNCH ITEM'),
          ),
        ),
        const SizedBox(height: 12),
        BpCard(
          child: Row(
            children: [
              _stat('Open', count('Open'), kBad),
              _stat('Fixed', count('Fixed'), kAccent),
              _stat('Verified', count('Verified'), kGood),
            ],
          ),
        ),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final f in ['All', ...kDefectStatuses]) bpChip(f, _filter == f, () => setState(() => _filter = f)),
          ],
        ),
        const SizedBox(height: 10),
        if (shown.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('No defects here. Log deficiencies with photos, a responsible party and a due date.', textAlign: TextAlign.center),
          ),
        for (final d in shown)
          BpCard(
            onTap: () => _open(d),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(d.no, style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold, color: kCyan)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        d.title.isEmpty ? '(untitled)' : d.title,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(border: Border.all(color: defectColor(d.status)), borderRadius: BorderRadius.circular(2)),
                      child: Text(d.status.toUpperCase(), style: TextStyle(color: defectColor(d.status), fontSize: 11, fontFamily: kMono)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  [
                    if (d.location.isNotEmpty) d.location,
                    if (d.trade.isNotEmpty) d.trade,
                    if (d.responsible.isNotEmpty) 'Resp: ${d.responsible}',
                  ].join('  |  '),
                  style: const TextStyle(fontSize: 12, color: kLine),
                ),
                if (d.due != null)
                  Text(
                    'Due ${fmtDate(d.due!)}${isOverdue(d) ? '  (OVERDUE)' : ''}',
                    style: TextStyle(fontSize: 12, color: isOverdue(d) ? kBad : kPaper, fontWeight: isOverdue(d) ? FontWeight.bold : FontWeight.normal),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

// ============================================================== detail

class DefectScreen extends StatefulWidget {
  const DefectScreen({super.key, required this.project, required this.defect});
  final Project project;
  final Defect defect;

  @override
  State<DefectScreen> createState() => _DefectScreenState();
}

class _DefectScreenState extends State<DefectScreen> {
  Defect get d => widget.defect;
  late final _title = TextEditingController(text: d.title);
  late final _desc = TextEditingController(text: d.desc);
  late final _loc = TextEditingController(text: d.location);
  late final _resp = TextEditingController(text: d.responsible);
  late final _pin = TextEditingController(text: d.pin?.toString() ?? '');

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _loc.dispose();
    _resp.dispose();
    _pin.dispose();
    Store.i.save();
    super.dispose();
  }

  Future<void> _pick(bool before) async {
    final src = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: kBlueDark,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Camera'), onTap: () => Navigator.pop(ctx, 'cam')),
            ListTile(leading: const Icon(Icons.photo_library), title: const Text('Gallery'), onTap: () => Navigator.pop(ctx, 'gal')),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    PhotoItem? item;
    if (src == 'cam') {
      final res = await Navigator.push<List<PhotoItem>>(
        context,
        MaterialPageRoute(
          builder: (_) => CameraScreen(
            projectName: Store.i.settings.stampProject ? widget.project.name : null,
            single: true,
          ),
        ),
      );
      if (res != null && res.isNotEmpty) item = res.first;
    } else {
      final res = await runWithLoader(context, 'Importing…', () => PhotoService.importFromGallery(multi: false));
      if (res.isNotEmpty) item = res.first;
    }
    if (item == null) return;
    final PhotoItem picked = item;
    final old = before ? d.before : d.after;
    if (old != null) {
      for (final f in old.allFiles) {
        await Store.i.deleteMedia(f);
      }
    }
    setState(() {
      if (before) {
        d.before = picked;
      } else {
        d.after = picked;
      }
    });
    Store.i.saveSoon();
  }

  Future<void> _removePhoto(bool before) async {
    final old = before ? d.before : d.after;
    if (old == null) return;
    for (final f in old.allFiles) {
      await Store.i.deleteMedia(f);
    }
    setState(() {
      if (before) {
        d.before = null;
      } else {
        d.after = null;
      }
    });
    Store.i.saveSoon();
  }

  Widget _photoCard(String label, PhotoItem? ph, bool before) {
    return BpCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BpLabel(label),
          if (ph != null) ...[
            GestureDetector(
              onTap: () => showPhotoViewer(context, ph),
              child: AspectRatio(
                aspectRatio: 4 / 3,
                child: Image.file(File(Store.i.mediaPath(ph.file)), fit: BoxFit.cover, cacheWidth: 800),
              ),
            ),
            if (ph.takenAt != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(fmtDateTime(ph.takenAt!), style: const TextStyle(fontSize: 11, color: kLine)),
              ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                OutlinedButton(onPressed: () => _pick(before), child: const Text('REPLACE')),
                OutlinedButton(onPressed: () => _removePhoto(before), child: const Text('REMOVE')),
              ],
            ),
          ] else
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => _pick(before),
                icon: const Icon(Icons.add_a_photo),
                label: const Text('ADD PHOTO'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _textField(String label, TextEditingController c, void Function(String) set, {bool mic = false, int lines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: TextField(
              controller: c,
              minLines: lines,
              maxLines: lines == 1 ? 1 : 8,
              textCapitalization: TextCapitalization.sentences,
              decoration: deco(label),
              onChanged: (v) {
                set(v);
                Store.i.saveSoon();
              },
            ),
          ),
          if (mic)
            MicButton(
              controller: c,
              onText: (v) {
                set(v);
                Store.i.saveSoon();
              },
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pr = widget.project;
    return BpScaffold(
      title: d.no,
      actions: [
        IconButton(
          tooltip: 'Delete defect',
          icon: const Icon(Icons.delete_outline),
          onPressed: () async {
            if (await confirm(context, 'Delete defect', 'Delete ${d.no} and its photos?')) {
              for (final f in d.allFiles) {
                await Store.i.deleteMedia(f);
              }
              pr.defects.remove(d);
              await Store.i.save();
              if (context.mounted) Navigator.pop(context);
            }
          },
        ),
      ],
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Defect details'),
                _textField('Title', _title, (v) => d.title = v.trim()),
                _textField('Description', _desc, (v) => d.desc = v, mic: true, lines: 3),
                _textField('Location (e.g. Level 2, Grid C-4)', _loc, (v) => d.location = v.trim()),
                _textField('Responsible party', _resp, (v) => d.responsible = v.trim()),
                const BpLabel('Trade'),
                if (pr.trades.isEmpty)
                  const Text('Add trades in the TRADES tab to link a defect to one.', style: TextStyle(fontSize: 12, color: kLine))
                else
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final t in pr.trades)
                        bpChip(t.name, d.trade == t.name, () {
                          setState(() => d.trade = d.trade == t.name ? '' : t.name);
                          Store.i.saveSoon();
                        }),
                    ],
                  ),
                const SizedBox(height: 12),
                const BpLabel('Due date'),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.event),
                        label: Text(d.due == null ? 'Set due date' : fmtDate(d.due!)),
                        onPressed: () async {
                          final x = await showDatePicker(
                            context: context,
                            initialDate: d.due ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (x != null) {
                            setState(() => d.due = x);
                            Store.i.saveSoon();
                          }
                        },
                      ),
                    ),
                    if (d.due != null)
                      IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          setState(() => d.due = null);
                          Store.i.saveSoon();
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                const BpLabel('Status'),
                ChipPicker(
                  presets: kDefectStatuses,
                  value: d.status,
                  customHint: 'Type your own status',
                  onChanged: (v) {
                    setState(() => d.status = v.isEmpty ? 'Open' : v);
                    Store.i.saveSoon();
                  },
                ),
              ],
            ),
          ),
          _photoCard('Before photo', d.before, true),
          _photoCard('After photo (fixed)', d.after, false),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Keyplan link'),
                if (pr.keyplans.isEmpty)
                  const Text('Upload a keyplan in the KEYPLANS tab, then link this defect to its pin number.', style: TextStyle(fontSize: 12, color: kLine))
                else ...[
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final k in pr.keyplans)
                        bpChip(k.name, d.keyplanId == k.id, () {
                          setState(() => d.keyplanId = d.keyplanId == k.id ? null : k.id);
                          Store.i.saveSoon();
                        }),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _pin,
                    keyboardType: TextInputType.number,
                    decoration: deco('Pin number on the keyplan'),
                    onChanged: (v) {
                      d.pin = int.tryParse(v.trim());
                      Store.i.saveSoon();
                    },
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
