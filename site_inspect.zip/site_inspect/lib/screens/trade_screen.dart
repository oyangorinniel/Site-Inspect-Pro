import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'inspection_screen.dart';

class TradeScreen extends StatefulWidget {
  const TradeScreen({super.key, required this.project, required this.trade});
  final Project project;
  final Trade trade;

  @override
  State<TradeScreen> createState() => _TradeScreenState();
}

class _TradeScreenState extends State<TradeScreen> {
  Trade get t => widget.trade;

  void _changed() {
    Store.i.saveSoon();
    setState(() {});
  }

  Future<void> _newInspection() async {
    final s = Store.i.settings;
    final ins = Inspection(date: DateTime.now(), inspectorName: s.lastName, role: s.lastRole, company: s.lastCompany);
    t.inspections.add(ins);
    await Store.i.save();
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => InspectionScreen(project: widget.project, trade: t, inspection: ins)),
    );
    setState(() {});
  }

  Color _statusColor(String s) {
    final l = s.toLowerCase();
    if (l.contains('pass') || l.contains('approved') || l.contains('complete')) return kGood;
    if (l.contains('fail') || l.contains('reject') || l.contains('rework')) return kBad;
    return kAccent;
  }

  @override
  Widget build(BuildContext context) {
    final list = [...t.inspections]..sort((a, b) => b.date.compareTo(a.date));
    return DefaultTabController(
      length: 2,
      child: BpScaffold(
        title: t.name,
        bottom: const TabBar(
          indicatorColor: kAccent,
          labelColor: kAccent,
          unselectedLabelColor: kLine,
          labelStyle: TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold, fontSize: 12),
          tabs: [Tab(text: 'PROGRESS'), Tab(text: 'INSPECTIONS')],
        ),
        body: TabBarView(
          children: [
            ProgressSection(heading: '${t.name} progress', entries: t.progress, onChanged: _changed),
            ListView(
              padding: const EdgeInsets.all(14),
              children: [
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.add_a_photo),
                    label: const Text('NEW INSPECTION'),
                    onPressed: _newInspection,
                  ),
                ),
                const SizedBox(height: 12),
                if (list.isEmpty)
                  const Padding(padding: EdgeInsets.all(24), child: Text('No inspections yet.', textAlign: TextAlign.center)),
                for (final i in list)
                  BpCard(
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => InspectionScreen(project: widget.project, trade: t, inspection: i)),
                      );
                      setState(() {});
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(fmtDate(i.date), style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                border: Border.all(color: _statusColor(i.status)),
                                borderRadius: BorderRadius.circular(2),
                              ),
                              child: Text(i.status.toUpperCase(), style: TextStyle(color: _statusColor(i.status), fontSize: 11, fontFamily: kMono)),
                            ),
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              icon: const Icon(Icons.delete_outline, size: 20),
                              onPressed: () async {
                                if (await confirm(context, 'Delete inspection', 'Delete the inspection of ${fmtDate(i.date)} and its photos?')) {
                                  for (final f in i.allFiles) {
                                    await Store.i.deleteMedia(f);
                                  }
                                  t.inspections.remove(i);
                                  _changed();
                                }
                              },
                            ),
                          ],
                        ),
                        Text(
                          [
                            if (i.inspectorName.isNotEmpty) i.inspectorName,
                            if (i.role.isNotEmpty) i.role,
                            if (i.company.isNotEmpty) i.company,
                          ].join('  |  '),
                          style: const TextStyle(fontSize: 12, color: kLine),
                        ),
                        if (i.notes.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(i.notes, maxLines: 2, overflow: TextOverflow.ellipsis),
                          ),
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Row(children: [
                            const Icon(Icons.photo_library, size: 14, color: kCyan),
                            const SizedBox(width: 4),
                            Text('${i.photos.length} photos', style: const TextStyle(fontSize: 12)),
                          ]),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
