import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'lock_screen.dart';
import 'templates_screen.dart';

Uint8List _logoJob(Uint8List bytes) {
  final im = img.decodeImage(bytes);
  if (im == null) return bytes;
  final r = im.width > 500 ? img.copyResize(im, width: 500) : im;
  return Uint8List.fromList(img.encodePng(r));
}

const _accents = [0xFF0F3D73, 0xFF1B5E20, 0xFFB71C1C, 0xFFE65100, 0xFF4A148C, 0xFF263238];

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  AppSettings get s => Store.i.settings;
  late final _company = TextEditingController(text: s.lastCompany);
  late final _license = TextEditingController(text: s.license);
  late final _contact = TextEditingController(text: s.contact);
  late final _footer = TextEditingController(text: s.footer);

  @override
  void dispose() {
    _company.dispose();
    _license.dispose();
    _contact.dispose();
    _footer.dispose();
    Store.i.save();
    super.dispose();
  }

  Future<void> _pickLogo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x == null || !mounted) return;
    final bytes = await x.readAsBytes();
    final small = await compute(_logoJob, bytes);
    if (s.logoFile != null) await Store.i.deleteMedia(s.logoFile!);
    s.logoFile = await Store.i.addMediaBytes(small, 'png');
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<void> _removeLogo() async {
    if (s.logoFile != null) await Store.i.deleteMedia(s.logoFile!);
    s.logoFile = null;
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Future<bool> _verifyPin() async {
    final p = await askText(context, 'Enter current PIN', hint: 'PIN', keyboard: TextInputType.number, obscure: true);
    if (p == null) return false;
    if (hashPin(p) == s.pinHash) return true;
    if (mounted) toast(context, 'Incorrect PIN');
    return false;
  }

  Future<void> _setPin() async {
    if (s.pinHash != null && !await _verifyPin()) return;
    if (!mounted) return;
    final a = await askText(context, 'New PIN', hint: '4 to 6 digits', keyboard: TextInputType.number, obscure: true);
    if (a == null) return;
    if (!RegExp(r'^\d{4,6}$').hasMatch(a)) {
      if (mounted) toast(context, 'PIN must be 4 to 6 digits');
      return;
    }
    if (!mounted) return;
    final b = await askText(context, 'Confirm PIN', hint: 'Repeat PIN', keyboard: TextInputType.number, obscure: true);
    if (b != a) {
      if (mounted) toast(context, 'PINs did not match');
      return;
    }
    s.pinHash = hashPin(a);
    await Store.i.save();
    if (mounted) {
      setState(() {});
      toast(context, 'App lock is on');
    }
  }

  Future<void> _removePin() async {
    if (!await _verifyPin()) return;
    s.pinHash = null;
    await Store.i.save();
    if (mounted) setState(() {});
  }

  String get _backupText {
    final b = s.lastBackup;
    if (b == null) return 'Never backed up';
    final days = DateTime.now().difference(b).inDays;
    return 'Last backup ${fmtDate(b)} (${days == 0 ? 'today' : '$days days ago'})';
  }

  Widget _field(String label, TextEditingController c, void Function(String) set, {int lines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        minLines: lines,
        maxLines: lines,
        textCapitalization: TextCapitalization.words,
        decoration: deco(label),
        onChanged: (v) {
          set(v.trim());
          Store.i.saveSoon();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BpScaffold(
      title: 'Settings',
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Report branding'),
                Container(
                  height: 84,
                  width: double.infinity,
                  color: Colors.white,
                  alignment: Alignment.center,
                  child: s.logoFile == null
                      ? const Text('No logo', style: TextStyle(color: Colors.black45))
                      : Image.file(File(Store.i.mediaPath(s.logoFile!)), fit: BoxFit.contain),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    FilledButton.icon(onPressed: _pickLogo, icon: const Icon(Icons.image), label: const Text('CHOOSE LOGO')),
                    if (s.logoFile != null) OutlinedButton(onPressed: _removeLogo, child: const Text('REMOVE')),
                  ],
                ),
                const SizedBox(height: 14),
                _field('Company name', _company, (v) => s.lastCompany = v),
                _field('Licence / PRC number', _license, (v) => s.license = v),
                _field('Contact (address, phone, email)', _contact, (v) => s.contact = v, lines: 2),
                _field('Footer text on every page', _footer, (v) => s.footer = v),
                const BpLabel('Report accent colour'),
                Wrap(
                  spacing: 10,
                  children: [
                    for (final c in _accents)
                      GestureDetector(
                        onTap: () {
                          setState(() => s.accent = c);
                          Store.i.saveSoon();
                        },
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: Color(c),
                            shape: BoxShape.circle,
                            border: Border.all(color: s.accent == c ? kAccent : Colors.white54, width: s.accent == c ? 3 : 1),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text('Reports stay on white pages; the accent colour is used for headings and table headers.', style: TextStyle(fontSize: 11, color: kLine)),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('App lock'),
                Text(s.pinHash == null ? 'Off. Anyone who opens the app can see your projects.' : 'On. The app asks for your PIN when opened and after 2 minutes in the background.'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: _setPin,
                      icon: const Icon(Icons.lock),
                      label: Text(s.pinHash == null ? 'SET PIN' : 'CHANGE PIN'),
                    ),
                    if (s.pinHash != null) OutlinedButton(onPressed: _removePin, child: const Text('TURN OFF')),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Note: the PIN blocks the screen only. Backup files are not encrypted, and there is no PIN recovery: if you forget it, you must reinstall the app (and restore a backup).',
                  style: TextStyle(fontSize: 11, color: kLine),
                ),
              ],
            ),
          ),
          BpCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BpLabel('Backup'),
                Text(_backupText),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: () async {
                    final f = await runWithLoader(context, 'Preparing backup…', Store.i.exportBackup);
                    await Share.shareXFiles([XFile(f.path)], subject: 'Site Inspect backup');
                    if (mounted) setState(() {});
                  },
                  icon: const Icon(Icons.backup),
                  label: const Text('BACK UP NOW'),
                ),
                const SizedBox(height: 6),
                const Text('Send the file to Google Drive, OneDrive or email from the share menu.', style: TextStyle(fontSize: 11, color: kLine)),
              ],
            ),
          ),
          BpCard(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TemplatesScreen())),
            child: const Row(
              children: [
                Icon(Icons.checklist, color: kCyan),
                SizedBox(width: 12),
                Expanded(child: Text('Checklist templates', style: TextStyle(fontWeight: FontWeight.bold))),
                Icon(Icons.chevron_right),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
