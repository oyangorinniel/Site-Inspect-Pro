import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:pdfx/pdfx.dart';

import '../calc.dart';
import '../export/export_sheet.dart';
import '../models.dart';
import '../scurve.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'defects_screen.dart';
import 'keyplan_screen.dart';
import 'search_screen.dart';
import 'sitelog_screen.dart';
import 'trade_screen.dart';

class ProjectScreen extends StatefulWidget {
  const ProjectScreen({super.key, required this.project});
  final Project project;

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  Project get pr => widget.project;

  void _changed() {
    Store.i.saveSoon();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: BpScaffold(
        title: pr.name,
        actions: [
          IconButton(
            tooltip: 'Search inspections',
            icon: const Icon(Icons.search),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => SearchScreen(project: pr)));
              if (mounted) setState(() {});
            },
          ),
          IconButton(
            tooltip: 'Generate report',
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () => showExportSheet(context, pr),
          ),
        ],
        bottom: const TabBar(
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          indicatorColor: kAccent,
          labelColor: kAccent,
          unselectedLabelColor: kLine,
          labelStyle: TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold, fontSize: 12),
          tabs: [
            Tab(text: 'PROGRESS'),
            Tab(text: 'TRADES'),
            Tab(text: 'KEYPLANS'),
            Tab(text: 'PUNCH LIST'),
            Tab(text: 'SITE LOG'),
          ],
        ),
        body: TabBarView(
          children: [
            _progressTab(),
            _tradesTab(),
            _keyplansTab(),
            DefectsTab(project: pr, onChanged: _changed),
            SiteLogTab(project: pr, onChanged: _changed),
          ],
        ),
      ),
    );
  }

  // --------------------------------------------------------------- progress

  Widget _progressTab() {
    return ProgressSection(
      heading: pr.weighted ? 'Overall (calculated from trades)' : 'Overall project progress',
      entries: pr.progress,
      onChanged: _changed,
      computed: pr.weighted,
      valueOverride: overallPercent(pr),
      dateOverride: overallDate(pr),
      extra: [
        _weightCard(),
        _scurveCard(),
        if (pr.trades.isNotEmpty) ..._snapshot(),
        if (!pr.weighted) const BpLabel('Overall progress log'),
      ],
    );
  }

  Widget _weightCard() {
    return BpCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('Calculate overall % from trade weights', style: TextStyle(fontWeight: FontWeight.bold))),
              Switch(
                value: pr.weighted,
                onChanged: (v) {
                  pr.weighted = v;
                  _changed();
                },
              ),
            ],
          ),
          Text(
            pr.weighted
                ? 'Each trade counts by its weight. Change a weight from the trade menu in the TRADES tab. Manual overall entries are hidden but kept.'
                : 'Off: you type the overall percentage yourself.',
            style: const TextStyle(fontSize: 12, color: kLine),
          ),
        ],
      ),
    );
  }

  Widget _legend(Color c, String label, {bool dashed = false}) => Padding(
        padding: const EdgeInsets.only(right: 14),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: dashed ? 8 : 18, height: 3, color: c),
            if (dashed) const SizedBox(width: 3),
            if (dashed) Container(width: 8, height: 3, color: c),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      );

  Widget _scurveCard() {
    final v = scheduleVariance(pr);
    return BpCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const BpLabel('Planned vs actual (S-curve)'),
          SizedBox(
            height: 190,
            width: double.infinity,
            child: CustomPaint(painter: SCurvePainter(planned: plannedSeries(pr), actual: actualSeries(pr))),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _legend(kCyan, 'Planned', dashed: true),
              _legend(kAccent, 'Actual'),
              const Spacer(),
              if (v != null)
                Text(varianceText(v), style: TextStyle(fontWeight: FontWeight.bold, color: v >= -0.5 ? kGood : kBad)),
            ],
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('ADD PLANNED POINT'),
            onPressed: () async {
              final last = sortedEntries(pr.planned).isEmpty ? 0.0 : sortedEntries(pr.planned).last.percent;
              final r = await showProgressDialog(context, suggest: last, title: 'PLANNED POINT');
              if (r != null) {
                pr.planned.add(r);
                _changed();
              }
            },
          ),
          for (final e in sortedEntries(pr.planned))
            InkWell(
              onTap: () async {
                final r = await showProgressDialog(context, existing: e, title: 'PLANNED POINT');
                if (r != null) {
                  e
                    ..date = r.date
                    ..percent = r.percent
                    ..note = r.note;
                  _changed();
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    const Icon(Icons.flag, size: 14, color: kCyan),
                    const SizedBox(width: 6),
                    Text(fmtDate(e.date), style: const TextStyle(fontFamily: kMono)),
                    const Spacer(),
                    Text(fmtPct(e.percent), style: const TextStyle(fontFamily: kMono, color: kCyan)),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.delete_outline, size: 18),
                      onPressed: () {
                        pr.planned.remove(e);
                        _changed();
                      },
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _snapshot() {
    return [
      const BpLabel('Trades snapshot'),
      BpCard(
        child: Column(
          children: [
            for (final t in pr.trades)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    Expanded(
                      flex: 4,
                      child: Text(pr.weighted ? '${t.name} (w ${_w(t.weight)})' : t.name, overflow: TextOverflow.ellipsis),
                    ),
                    Expanded(
                      flex: 5,
                      child: LinearProgressIndicator(
                        value: tradeLatest(t) / 100,
                        minHeight: 6,
                        backgroundColor: kLine.withAlpha(40),
                        color: kCyan,
                      ),
                    ),
                    SizedBox(
                      width: 52,
                      child: Text(
                        latestEntry(t.progress) == null ? '--' : fmtPct(latestEntry(t.progress)!.percent),
                        textAlign: TextAlign.right,
                        style: const TextStyle(fontFamily: kMono),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
      const SizedBox(height: 4),
    ];
  }

  String _w(double w) => w.toStringAsFixed(w % 1 == 0 ? 0 : 1);

  // ----------------------------------------------------------------- trades

  Widget _tradesTab() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('ADD TRADE / INSPECTION CATEGORY'),
            onPressed: () async {
              final n = await askText(context, 'Add trade', hint: 'Trade name', suggestions: kTradeSuggestions);
              if (n != null && n.isNotEmpty) {
                pr.trades.add(Trade(name: n));
                _changed();
              }
            },
          ),
        ),
        const SizedBox(height: 12),
        if (pr.trades.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('Add a trade (Electrical, Plumbing, Structural, or your own) to start logging inspections.', textAlign: TextAlign.center),
          ),
        for (final t in pr.trades)
          BpCard(
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => TradeScreen(project: pr, trade: t)));
              if (mounted) setState(() {});
            },
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.name.toUpperCase(), style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 4),
                      Text(
                        '${t.inspections.length} inspections  |  weight ${_w(t.weight)}',
                        style: const TextStyle(fontSize: 12, color: kLine),
                      ),
                    ],
                  ),
                ),
                Text(
                  latestEntry(t.progress) == null ? '--' : fmtPct(latestEntry(t.progress)!.percent),
                  style: const TextStyle(fontFamily: kMono, fontSize: 22, color: kAccent, fontWeight: FontWeight.bold),
                ),
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'rename') {
                      final n = await askText(context, 'Rename trade', initial: t.name, suggestions: kTradeSuggestions);
                      if (n != null && n.isNotEmpty) {
                        t.name = n;
                        _changed();
                      }
                    } else if (v == 'weight') {
                      final x = await askText(
                        context,
                        'Trade weight',
                        initial: _w(t.weight),
                        hint: 'Relative weight, e.g. 3',
                        keyboard: const TextInputType.numberWithOptions(decimal: true),
                      );
                      final w = double.tryParse(x ?? '');
                      if (w != null && w > 0) {
                        t.weight = w;
                        _changed();
                      }
                    } else if (v == 'delete') {
                      if (await confirm(context, 'Delete trade', 'Delete "${t.name}" and all its inspections and photos?')) {
                        for (final f in t.allFiles) {
                          await Store.i.deleteMedia(f);
                        }
                        pr.trades.remove(t);
                        _changed();
                      }
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'rename', child: Text('Rename')),
                    PopupMenuItem(value: 'weight', child: Text('Set weight')),
                    PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ],
            ),
          ),
      ],
    );
  }

  // --------------------------------------------------------------- keyplans

  Future<List<int>?> _pickPages(int n) {
    final chosen = <int>{1};
    return showDialog<List<int>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('SELECT PDF PAGES', style: TextStyle(fontFamily: kMono, fontSize: 16)),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('This PDF has $n pages. Each selected page becomes its own keyplan sheet.'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (var i = 1; i <= n; i++)
                      bpChip('$i', chosen.contains(i), () => setS(() => chosen.contains(i) ? chosen.remove(i) : chosen.add(i))),
                  ],
                ),
                TextButton(
                  onPressed: () => setS(() {
                    chosen
                      ..clear()
                      ..addAll([for (var i = 1; i <= n; i++) i]);
                  }),
                  child: const Text('Select all'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, chosen.toList()..sort()), child: const Text('Import')),
          ],
        ),
      ),
    );
  }

  Future<void> _addKeyplan() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'],
    );
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    final base = p.basenameWithoutExtension(path);
    final ext = p.extension(path).toLowerCase().replaceFirst('.', '');

    if (ext == 'pdf') {
      final doc = await PdfDocument.openFile(path);
      final n = doc.pagesCount;
      final pages = n == 1 ? [1] : await _pickPages(n);
      if (pages == null || pages.isEmpty || !mounted) {
        await doc.close();
        return;
      }
      await runWithLoader(context, 'Importing PDF pages…', () async {
        for (final pg in pages) {
          final page = await doc.getPage(pg);
          final sc = (2000 / page.width).clamp(1.0, 4.0).toDouble();
          final im = await page.render(
            width: page.width * sc,
            height: page.height * sc,
            format: PdfPageImageFormat.png,
            backgroundColor: '#FFFFFF',
          );
          await page.close();
          if (im != null) {
            final f = await Store.i.addMediaBytes(im.bytes, 'png');
            pr.keyplans.add(Keyplan(name: n == 1 ? base : '$base - page $pg', file: f));
          }
        }
      });
      await doc.close();
    } else {
      final f = await Store.i.addMediaBytes(await File(path).readAsBytes(), ext);
      pr.keyplans.add(Keyplan(name: base, file: f));
    }
    await Store.i.save();
    if (mounted) setState(() {});
  }

  Widget _keyplansTab() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            icon: const Icon(Icons.upload_file),
            label: const Text('UPLOAD KEYPLAN (IMAGE OR PDF)'),
            onPressed: _addKeyplan,
          ),
        ),
        const SizedBox(height: 12),
        if (pr.keyplans.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('Upload a floor plan or site plan, then pin numbers, arrows, circles and notes on it.', textAlign: TextAlign.center),
          ),
        for (final k in pr.keyplans)
          BpCard(
            padding: const EdgeInsets.all(8),
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => KeyplanScreen(title: k.name, file: k.file, markups: k.markups)),
              );
              Store.i.saveSoon();
              if (mounted) setState(() {});
            },
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(2),
                  child: Container(
                    width: 84,
                    height: 64,
                    color: Colors.white,
                    child: Image.file(File(Store.i.mediaPath(k.file)), fit: BoxFit.cover, cacheWidth: 300),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(k.name, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
                      Text('${k.markups.length} markups', style: const TextStyle(fontSize: 12, color: kLine)),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'rename') {
                      final n = await askText(context, 'Rename keyplan', initial: k.name);
                      if (n != null && n.isNotEmpty) {
                        k.name = n;
                        _changed();
                      }
                    } else if (v == 'delete') {
                      if (await confirm(context, 'Delete keyplan', 'Delete "${k.name}" and its markups?')) {
                        await Store.i.deleteMedia(k.file);
                        pr.keyplans.remove(k);
                        _changed();
                      }
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'rename', child: Text('Rename')),
                    PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ],
            ),
          ),
      ],
    );
  }
}
