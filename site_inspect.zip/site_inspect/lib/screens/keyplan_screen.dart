import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../markup_painter.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

enum Tool { hand, select, pin, arrow, circle, pen, text, rect, line }

enum _Drag { none, move, h1, h2, draw }

const _palette = [
  0xFFFF3B30,
  0xFFFF9500,
  0xFFFFD60A,
  0xFF34C759,
  0xFF0A84FF,
  0xFFFF2D95,
  0xFF000000,
  0xFFFFFFFF,
];

MarkType? _typeOf(Tool t) {
  switch (t) {
    case Tool.pin:
      return MarkType.pin;
    case Tool.arrow:
      return MarkType.arrow;
    case Tool.circle:
      return MarkType.circle;
    case Tool.pen:
      return MarkType.pen;
    case Tool.text:
      return MarkType.text;
    case Tool.rect:
      return MarkType.rect;
    case Tool.line:
      return MarkType.line;
    default:
      return null;
  }
}

class KeyplanScreen extends StatefulWidget {
  const KeyplanScreen({super.key, required this.title, required this.file, required this.markups});
  final String title;
  final String file;
  final List<Markup> markups;

  @override
  State<KeyplanScreen> createState() => _KeyplanScreenState();
}

class _KeyplanScreenState extends State<KeyplanScreen> {
  List<Markup> get _items => widget.markups;

  ui.Image? _img;
  Tool _tool = Tool.hand;
  Markup? _sel;
  final _tc = TransformationController();

  int _color = 0xFFFF3B30;
  double _weight = 3;
  double _size = 14;

  final List<String> _undo = [];
  Size _canvas = const Size(1, 1);
  _Drag _drag = _Drag.none;
  Offset _last = Offset.zero;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final bytes = await File(Store.i.mediaPath(widget.file)).readAsBytes();
    final im = await decodeImageFromList(bytes);
    if (mounted) setState(() => _img = im);
  }

  @override
  void dispose() {
    _tc.dispose();
    _img?.dispose();
    Store.i.save();
    super.dispose();
  }

  // ------------------------------------------------------------- helpers

  double get _s => _canvas.width / kRef;
  Offset _n(Offset px) => Offset(px.dx / _canvas.width, px.dy / _canvas.height);

  void _push() {
    _undo.add(jsonEncode(_items.map((e) => e.toJson()).toList()));
    if (_undo.length > 60) _undo.removeAt(0);
  }

  void _undoLast() {
    if (_undo.isEmpty) return;
    final list = jsonDecode(_undo.removeLast()) as List;
    setState(() {
      _items
        ..clear()
        ..addAll(list.map((e) => Markup.fromJson(Map<String, dynamic>.from(e))));
      _sel = null;
    });
    Store.i.saveSoon();
  }

  int _nextNumber() {
    var m = 0;
    for (final k in _items) {
      if (k.type == MarkType.pin && k.number > m) m = k.number;
    }
    return m + 1;
  }

  Markup? _hit(Offset pos) {
    for (final mk in _items.reversed) {
      if (hitMarkup(mk, pos, _canvas, _s)) return mk;
    }
    return null;
  }

  int _handleAt(Markup mk, Offset pos) {
    for (final h in handlesPx(mk, _canvas)) {
      if ((h.$2 - pos).distance <= 24 * _s) return h.$1;
    }
    return 0;
  }

  void _add(Markup mk) {
    _items.add(mk);
    _sel = mk;
  }

  // ------------------------------------------------------------ gestures

  Future<void> _onTapUp(TapUpDetails d) async {
    final pos = d.localPosition;
    switch (_tool) {
      case Tool.pin:
        _push();
        setState(() => _add(Markup(
              type: MarkType.pin,
              p1: _n(pos),
              color: _color,
              size: _size,
              weight: _weight,
              number: _nextNumber(),
            )));
        Store.i.saveSoon();
      case Tool.text:
        final t = await askText(context, 'Text label', hint: 'Label text', multiline: true);
        if (t == null || t.isEmpty) return;
        _push();
        setState(() => _add(Markup(type: MarkType.text, p1: _n(pos), color: _color, size: _size, text: t)));
        Store.i.saveSoon();
      case Tool.select:
        setState(() => _sel = _hit(pos));
      default:
        break;
    }
  }

  void _onPanStart(DragStartDetails d) {
    final pos = d.localPosition;
    _last = pos;
    if (_tool == Tool.select) {
      final cur = _sel;
      if (cur != null) {
        final h = _handleAt(cur, pos);
        if (h != 0) {
          _push();
          _drag = h == 1 ? _Drag.h1 : _Drag.h2;
          return;
        }
      }
      final hit = _hit(pos);
      setState(() => _sel = hit);
      if (hit != null) {
        _push();
        _drag = _Drag.move;
      } else {
        _drag = _Drag.none;
      }
      return;
    }
    final type = _typeOf(_tool);
    if (type == null || type == MarkType.pin || type == MarkType.text) {
      _drag = _Drag.none;
      return;
    }
    _push();
    final mk = Markup(type: type, p1: _n(pos), color: _color, weight: _weight);
    if (type == MarkType.pen) mk.pts = [_n(pos)];
    setState(() => _add(mk));
    _drag = _Drag.draw;
  }

  void _onPanUpdate(DragUpdateDetails d) {
    final pos = d.localPosition;
    final mk = _sel;
    if (mk == null || _drag == _Drag.none) return;
    setState(() {
      switch (_drag) {
        case _Drag.move:
          final delta = pos - _last;
          mk.shift(delta.dx / _canvas.width, delta.dy / _canvas.height);
        case _Drag.h1:
          mk.p1 = _n(pos);
        case _Drag.h2:
          mk.p2 = _n(pos);
        case _Drag.draw:
          if (mk.type == MarkType.pen) {
            mk.pts.add(_n(pos));
          } else {
            mk.p2 = _n(pos);
          }
        case _Drag.none:
          break;
      }
    });
    _last = pos;
  }

  void _onPanEnd(DragEndDetails d) {
    final mk = _sel;
    if (_drag == _Drag.draw && mk != null && mk.type != MarkType.pen) {
      final a = px(mk.p1, _canvas);
      final b = px(mk.p2, _canvas);
      if ((a - b).distance < 6) {
        setState(() {
          _items.remove(mk);
          _sel = null;
        });
        if (_undo.isNotEmpty) _undo.removeLast();
      }
    }
    _drag = _Drag.none;
    Store.i.saveSoon();
  }

  // -------------------------------------------------------- properties

  void _setColor(int c) {
    final mk = _sel;
    if (mk != null) {
      _push();
      mk.color = c;
    }
    setState(() => _color = c);
    Store.i.saveSoon();
  }

  Future<void> _editSelected() async {
    final mk = _sel;
    if (mk == null) return;
    if (mk.type == MarkType.pin) {
      final v = await askText(context, 'Pin number', initial: '${mk.number}', keyboard: TextInputType.number);
      final n = int.tryParse(v ?? '');
      if (n != null) {
        _push();
        setState(() => mk.number = n);
        Store.i.saveSoon();
      }
    } else if (mk.type == MarkType.text) {
      final v = await askText(context, 'Edit text', initial: mk.text, multiline: true);
      if (v != null && v.isNotEmpty) {
        _push();
        setState(() => mk.text = v);
        Store.i.saveSoon();
      }
    }
  }

  void _deleteSelected() {
    final mk = _sel;
    if (mk == null) return;
    _push();
    setState(() {
      _items.remove(mk);
      _sel = null;
    });
    Store.i.saveSoon();
  }

  // -------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return BpScaffold(
      title: widget.title,
      actions: [
        IconButton(
          tooltip: 'Undo',
          onPressed: _undo.isEmpty ? null : _undoLast,
          icon: const Icon(Icons.undo),
        ),
        IconButton(
          tooltip: 'Reset zoom',
          onPressed: () => setState(() => _tc.value = Matrix4.identity()),
          icon: const Icon(Icons.zoom_out_map),
        ),
      ],
      body: _img == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(child: _canvasArea()),
                _toolbar(),
                if (_tool != Tool.hand) _props(),
              ],
            ),
    );
  }

  Widget _canvasArea() {
    return LayoutBuilder(
      builder: (context, c) {
        final im = _img!;
        final ar = im.width / im.height;
        var w = c.maxWidth;
        var h = w / ar;
        if (h > c.maxHeight) {
          h = c.maxHeight;
          w = h * ar;
        }
        _canvas = Size(w, h);
        Widget canvas = SizedBox(
          width: w,
          height: h,
          child: CustomPaint(
            painter: KeyplanPainter(image: im, items: _items, selectedId: _sel?.id),
          ),
        );
        final area = SizedBox(width: c.maxWidth, height: c.maxHeight, child: Center(child: canvas));

        if (_tool == Tool.hand) {
          return ClipRect(
            child: InteractiveViewer(
              transformationController: _tc,
              minScale: 0.5,
              maxScale: 10,
              boundaryMargin: const EdgeInsets.all(300),
              child: area,
            ),
          );
        }
        // Drawing / selecting: keep the current zoom but give gestures to the canvas.
        canvas = GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: _onTapUp,
          onPanStart: _onPanStart,
          onPanUpdate: _onPanUpdate,
          onPanEnd: _onPanEnd,
          child: canvas,
        );
        return ClipRect(
          child: Transform(
            transform: _tc.value,
            child: SizedBox(width: c.maxWidth, height: c.maxHeight, child: Center(child: canvas)),
          ),
        );
      },
    );
  }

  Widget _toolBtn(Tool t, IconData icon, String label) {
    final on = _tool == t;
    return InkWell(
      onTap: () => setState(() {
        _tool = t;
        if (t != Tool.select) _sel = null;
      }),
      child: Container(
        width: 62,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: on ? kAccent : Colors.transparent,
          border: Border.all(color: on ? kAccent : kLine.withAlpha(100)),
          borderRadius: BorderRadius.circular(3),
        ),
        margin: const EdgeInsets.only(right: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 22, color: on ? Colors.black : kPaper),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 10, fontFamily: kMono, color: on ? Colors.black : kPaper)),
          ],
        ),
      ),
    );
  }

  Widget _toolbar() {
    return Container(
      color: kBlueDeep.withAlpha(235),
      padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _toolBtn(Tool.hand, Icons.pan_tool_alt, 'ZOOM'),
            _toolBtn(Tool.select, Icons.near_me, 'EDIT'),
            _toolBtn(Tool.pin, Icons.location_on, 'PIN'),
            _toolBtn(Tool.arrow, Icons.north_east, 'ARROW'),
            _toolBtn(Tool.circle, Icons.radio_button_unchecked, 'CIRCLE'),
            _toolBtn(Tool.pen, Icons.edit, 'PEN'),
            _toolBtn(Tool.text, Icons.title, 'TEXT'),
            _toolBtn(Tool.rect, Icons.crop_square, 'BOX'),
            _toolBtn(Tool.line, Icons.horizontal_rule, 'LINE'),
          ],
        ),
      ),
    );
  }

  Widget _props() {
    final mk = _sel;
    final type = mk?.type ?? _typeOf(_tool);
    final showWeight = type != null && type != MarkType.pin && type != MarkType.text;
    final showSize = type == MarkType.pin || type == MarkType.text;
    final color = mk?.color ?? _color;
    final weight = mk?.weight ?? _weight;
    final size = mk?.size ?? _size;

    return Container(
      color: kBlueDark.withAlpha(240),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_tool == Tool.select && mk == null)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('Tap a markup to select it. Drag to move; drag the white handles to resize.', style: TextStyle(fontSize: 12, color: kLine)),
              )
            else ...[
              Row(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          for (final c in _palette)
                            GestureDetector(
                              onTap: () => _setColor(c),
                              child: Container(
                                width: 28,
                                height: 28,
                                margin: const EdgeInsets.only(right: 8),
                                decoration: BoxDecoration(
                                  color: Color(c),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: color == c ? kAccent : Colors.white54, width: color == c ? 3 : 1),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  if (mk != null && (mk.type == MarkType.pin || mk.type == MarkType.text))
                    IconButton(tooltip: 'Edit number / text', icon: const Icon(Icons.edit_note), onPressed: _editSelected),
                  if (mk != null) IconButton(tooltip: 'Delete', icon: const Icon(Icons.delete, color: kBad), onPressed: _deleteSelected),
                ],
              ),
              if (showWeight)
                _slider('LINE WEIGHT', weight, 1, 14, (v) {
                  if (mk != null) mk.weight = v;
                  setState(() => _weight = v);
                }),
              if (showSize)
                _slider(type == MarkType.pin ? 'PIN SIZE' : 'TEXT SIZE', size, 8, 40, (v) {
                  if (mk != null) mk.size = v;
                  setState(() => _size = v);
                }),
            ],
          ],
        ),
      ),
    );
  }

  Widget _slider(String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Row(
      children: [
        SizedBox(width: 96, child: Text(label, style: const TextStyle(fontSize: 11, fontFamily: kMono, color: kCyan))),
        Expanded(
          child: Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            onChangeStart: (_) {
              if (_sel != null) _push();
            },
            onChanged: onChanged,
            onChangeEnd: (_) => Store.i.saveSoon(),
          ),
        ),
        SizedBox(width: 30, child: Text(value.toStringAsFixed(0), textAlign: TextAlign.right)),
      ],
    );
  }
}
