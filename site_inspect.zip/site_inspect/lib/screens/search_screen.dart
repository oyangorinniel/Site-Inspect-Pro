import 'package:flutter/material.dart';

import '../calc.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'inspection_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.project});
  final Project project;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  Project get pr => widget.project;
  final _q = TextEditingController();
  String? _status;
  String? _tradeId;
  DateTime? _from;
  DateTime? _to;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  List<(Trade, Inspection)> get _results {
    final q = _q.text.trim().toLowerCase();
    final out = <(Trade, Inspection)>[];
    for (final t in pr.trades) {
      if (_tradeId != null && t.id != _tradeId) continue;
      for (final i in t.inspections) {
        if (_status != null && i.status != _status) continue;
        if (_from != null && dateOnly(i.date).isBefore(dateOnly(_from!))) continue;
        if (_to != null && dateOnly(i.date).isAfter(dateOnly(_to!))) continue;
        if (q.isNotEmpty) {
          final hay = [
            t.name,
            i.status,
            i.notes,
            i.inspectorName,
            i.company,
            for (final p in i.photos) p.caption,
            for (final c in i.checklist) '${c.text} ${c.remark}',
          ].join(' ').toLowerCase();
          if (!hay.contains(q)) continue;
        }
        out.add((t, i));
      }
    }
    out.sort((a, b) => b.$2.date.compareTo(a.$2.date));
    return out;
  }

  Future<void> _pickDate(bool from) async {
    final d = await showDatePicker(
      context: context,
      initialDate: (from ? _from : _to) ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (d != null) {
      setState(() {
        if (from) {
          _from = d;
        } else {
          _to = d;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final statuses = <String>{for (final t in pr.trades) for (final i in t.inspections) i.status}.toList()..sort();
    final res = _results;
    return BpScaffold(
      title: 'Search inspections',
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          TextField(
            controller: _q,
            decoration: deco('Search notes, captions, inspector, checklist…', suffix: const Icon(Icons.search)),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          const BpLabel('Status'),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              bpChip('Any', _status == null, () => setState(() => _status = null)),
              for (final s in statuses) bpChip(s, _status == s, () => setState(() => _status = _status == s ? null : s)),
            ],
          ),
          const SizedBox(height: 10),
          const BpLabel('Trade'),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              bpChip('All', _tradeId == null, () => setState(() => _tradeId = null)),
              for (final t in pr.trades) bpChip(t.name, _tradeId == t.id, () => setState(() => _tradeId = _tradeId == t.id ? null : t.id)),
            ],
          ),
          const SizedBox(height: 10),
          const BpLabel('Date range'),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(onPressed: () => _pickDate(true), child: Text(_from == null ? 'From' : fmtDate(_from!))),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(onPressed: () => _pickDate(false), child: Text(_to == null ? 'To' : fmtDate(_to!))),
              ),
              if (_from != null || _to != null)
                IconButton(onPressed: () => setState(() => _from = _to = null), icon: const Icon(Icons.clear)),
            ],
          ),
          const SizedBox(height: 14),
          BpLabel('${res.length} result${res.length == 1 ? '' : 's'}'),
          for (final r in res)
            BpCard(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => InspectionScreen(project: pr, trade: r.$1, inspection: r.$2)),
                );
                if (mounted) setState(() {});
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(fmtDate(r.$2.date), style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
                      const SizedBox(width: 10),
                      Expanded(child: Text(r.$1.name, style: const TextStyle(color: kCyan), overflow: TextOverflow.ellipsis)),
                      Text(r.$2.status.toUpperCase(), style: const TextStyle(fontSize: 11, fontFamily: kMono, color: kAccent)),
                    ],
                  ),
                  if (r.$2.notes.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(r.$2.notes, maxLines: 2, overflow: TextOverflow.ellipsis),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
