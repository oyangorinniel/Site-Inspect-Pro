import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../models.dart';
import '../photo_service.dart';
import '../theme.dart';
import '../widgets.dart';

/// In-app camera. Stays open so several photos can be taken in a row.
/// Pops with the list of captured photos (stamped, original kept), or with
/// null if the camera could not be opened (caller falls back to system camera).
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key, required this.projectName, this.single = false});
  final String? projectName;
  final bool single;

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _c;
  List<CameraDescription> _cams = [];
  int _idx = 0;
  bool _busy = false;
  bool _dead = false;
  FlashMode _flash = FlashMode.off;
  Position? _pos;
  final List<PhotoItem> _shots = [];

  @override
  void initState() {
    super.initState();
    _init();
    _refreshPos();
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  Future<void> _refreshPos() async {
    final p = await PhotoService.currentPosition();
    if (p != null) _pos = p;
  }

  Future<void> _init() async {
    try {
      _cams = await availableCameras();
      if (_cams.isEmpty) throw Exception('No camera found');
      _idx = _cams.indexWhere((c) => c.lensDirection == CameraLensDirection.back);
      if (_idx < 0) _idx = 0;
      await _start();
    } catch (_) {
      if (mounted) setState(() => _dead = true);
    }
  }

  Future<void> _start() async {
    final old = _c;
    final c = CameraController(_cams[_idx], ResolutionPreset.veryHigh, enableAudio: false);
    _c = c;
    if (old != null) await old.dispose();
    await c.initialize();
    try {
      await c.setFlashMode(_flash);
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _flip() async {
    if (_cams.length < 2 || _busy) return;
    _idx = (_idx + 1) % _cams.length;
    try {
      await _start();
    } catch (_) {
      if (mounted) setState(() => _dead = true);
    }
  }

  Future<void> _toggleFlash() async {
    final c = _c;
    if (c == null) return;
    final next = _flash == FlashMode.off ? FlashMode.auto : (_flash == FlashMode.auto ? FlashMode.always : FlashMode.off);
    try {
      await c.setFlashMode(next);
      setState(() => _flash = next);
    } catch (_) {}
  }

  Future<void> _shoot() async {
    final c = _c;
    if (c == null || !c.value.isInitialized || _busy) return;
    setState(() => _busy = true);
    try {
      final x = await c.takePicture();
      final item = await PhotoService.processCapture(
        x,
        position: Future.value(_pos),
        projectName: widget.projectName,
        keepOriginal: true,
      );
      _shots.add(item);
      _refreshPos();
      if (widget.single && mounted) {
        Navigator.pop(context, _shots);
        return;
      }
    } catch (e) {
      if (mounted) toast(context, 'Could not take the photo');
    }
    if (mounted) setState(() => _busy = false);
  }

  void _done() => Navigator.pop(context, _shots);

  IconData get _flashIcon =>
      _flash == FlashMode.off ? Icons.flash_off : (_flash == FlashMode.auto ? Icons.flash_auto : Icons.flash_on);

  @override
  Widget build(BuildContext context) {
    if (_dead) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('The in-app camera could not be opened.', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () => Navigator.pop(context, _shots.isEmpty ? null : _shots),
                  child: const Text('Use phone camera instead'),
                ),
              ],
            ),
          ),
        ),
      );
    }
    final c = _c;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _done();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Positioned.fill(
              child: (c != null && c.value.isInitialized)
                  ? Center(child: CameraPreview(c))
                  : const Center(child: CircularProgressIndicator()),
            ),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: Row(
                      children: [
                        IconButton(onPressed: _done, icon: const Icon(Icons.close, color: Colors.white)),
                        const Spacer(),
                        IconButton(onPressed: _toggleFlash, icon: Icon(_flashIcon, color: Colors.white)),
                        if (_cams.length > 1)
                          IconButton(onPressed: _flip, icon: const Icon(Icons.cameraswitch, color: Colors.white)),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Container(
                    color: Colors.black45,
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 90,
                          child: Text(
                            widget.single ? '' : '${_shots.length} saved',
                            style: const TextStyle(color: Colors.white, fontFamily: kMono),
                          ),
                        ),
                        GestureDetector(
                          onTap: _shoot,
                          child: Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 4),
                              color: _busy ? Colors.white24 : Colors.white70,
                            ),
                            child: _busy ? const Padding(padding: EdgeInsets.all(22), child: CircularProgressIndicator(strokeWidth: 3)) : null,
                          ),
                        ),
                        SizedBox(
                          width: 90,
                          child: widget.single
                              ? null
                              : Align(
                                  alignment: Alignment.centerRight,
                                  child: FilledButton(onPressed: _done, child: const Text('DONE')),
                                ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
