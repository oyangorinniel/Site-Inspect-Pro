import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';

import '../store.dart';
import '../theme.dart';

String hashPin(String pin) => sha256.convert(utf8.encode('siteinspect:$pin')).toString();

/// Sits above the whole app (via MaterialApp.builder). Locks at start and when
/// the app has been in the background for more than 2 minutes.
class LockGate extends StatefulWidget {
  const LockGate({super.key, required this.child});
  final Widget child;

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  late bool _locked = Store.i.settings.pinHash != null;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final p = _pausedAt;
      _pausedAt = null;
      if (p != null &&
          Store.i.settings.pinHash != null &&
          DateTime.now().difference(p) > const Duration(minutes: 2)) {
        setState(() => _locked = true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        if (_locked)
          Positioned.fill(child: LockScreen(onUnlocked: () => setState(() => _locked = false))),
      ],
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key, required this.onUnlocked});
  final VoidCallback onUnlocked;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  bool _bad = false;

  void _check() {
    if (_pin.length < 4) return;
    if (hashPin(_pin) == Store.i.settings.pinHash) {
      widget.onUnlocked();
    } else {
      setState(() {
        _pin = '';
        _bad = true;
      });
    }
  }

  void _digit(String d) {
    if (_pin.length >= 6) return;
    setState(() {
      _pin += d;
      _bad = false;
    });
    // Unlock as soon as the typed digits match, without needing OK.
    if (_pin.length >= 4 && hashPin(_pin) == Store.i.settings.pinHash) {
      widget.onUnlocked();
    } else if (_pin.length == 6) {
      setState(() {
        _pin = '';
        _bad = true;
      });
    }
  }

  void _back() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Widget _key(Widget child, VoidCallback onTap) => SizedBox(
        width: 84,
        height: 60,
        child: OutlinedButton(onPressed: onTap, child: child),
      );

  @override
  Widget build(BuildContext context) {
    const mono = TextStyle(fontFamily: kMono, fontSize: 22, fontWeight: FontWeight.bold);
    return BpScaffold(
      title: 'Locked',
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock, size: 44, color: kAccent),
              const SizedBox(height: 10),
              const Text('ENTER PIN', style: TextStyle(fontFamily: kMono, letterSpacing: 2)),
              const SizedBox(height: 14),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < 6; i++)
                    Container(
                      width: 14,
                      height: 14,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i < _pin.length ? kAccent : Colors.transparent,
                        border: Border.all(color: _bad ? kBad : kLine),
                      ),
                    ),
                ],
              ),
              SizedBox(
                height: 28,
                child: Center(
                  child: Text(_bad ? 'Incorrect PIN' : '', style: const TextStyle(color: kBad)),
                ),
              ),
              for (final row in const [
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '9'],
              ])
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (final d in row)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: _key(Text(d, style: mono), () => _digit(d)),
                        ),
                    ],
                  ),
                ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: _key(const Icon(Icons.backspace_outlined), _back),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: _key(const Text('0', style: mono), () => _digit('0')),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: _key(const Icon(Icons.check), _check),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
