import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../calc.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'project_screen.dart';
import 'settings_screen.dart';
import 'templates_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _backupNow() async {
    final f = await runWithLoader(context, 'Preparing backup…', Store.i.exportBackup);
    await Share.shareXFiles([XFile(f.path)], subject: 'Site Inspect backup');
  }

  Future<void> _menu(String v) async {
    if (v == 'settings') {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
    } else if (v == 'templates') {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const TemplatesScreen()));
    } else if (v == 'backup') {
      await _backupNow();
    } else if (v == 'restore') {
      final ok = await confirm(
        context,
        'Restore backup',
        'This replaces everything currently in the app with the contents of the backup file.',
        yes: 'Choose file',
      );
      if (!ok) return;
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null || !mounted) return;
      final done = await runWithLoader(context, 'Restoring…', () => Store.i.restoreBackup(File(path)));
      if (mounted) toast(context, done ? 'Backup restored' : 'That is not a valid Site Inspect backup');
    }
  }

  Widget? _backupBanner() {
    final b = Store.i.settings.lastBackup;
    final days = b == null ? null : DateTime.now().difference(b).inDays;
    final stale = b == null || days! >= 7;
    if (!stale || Store.i.projects.isEmpty) return null;
    return BpCard(
      child: Row(
        children: [
          const Icon(Icons.warning_amber, color: kAccent),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              b == null ? 'You have never backed up your data.' : 'Your last backup was $days days ago.',
              style: const TextStyle(fontSize: 13),
            ),
          ),
          TextButton(onPressed: _backupNow, child: const Text('BACK UP')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, _) {
        final q = _search.text.trim().toLowerCase();
        final ps = Store.i.projects
            .where((p) => q.isEmpty || '${p.name} ${p.address} ${p.client}'.toLowerCase().contains(q))
            .toList();
        final banner = _backupBanner();
        return BpScaffold(
          title: 'Site Inspect',
          actions: [
            PopupMenuButton<String>(
              onSelected: _menu,
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'settings', child: Text('Settings, logo and app lock')),
                PopupMenuItem(value: 'templates', child: Text('Checklist templates')),
                PopupMenuItem(value: 'backup', child: Text('Export backup')),
                PopupMenuItem(value: 'restore', child: Text('Restore backup')),
              ],
            ),
          ],
          fab: FloatingActionButton.extended(
            onPressed: () => showProjectDialog(context),
            backgroundColor: kAccent,
            foregroundColor: Colors.black,
            icon: const Icon(Icons.add),
            label: const Text('NEW PROJECT', style: TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
          ),
          body: Store.i.projects.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.architecture, size: 72, color: kLine),
                        SizedBox(height: 12),
                        Text('NO PROJECTS YET', style: TextStyle(fontFamily: kMono, fontSize: 16, letterSpacing: 1.5)),
                        SizedBox(height: 6),
                        Text('Tap NEW PROJECT to start your first inspection log.', textAlign: TextAlign.center),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                  children: [
                    if (banner != null) banner,
                    TextField(
                      controller: _search,
                      decoration: deco('Search projects', suffix: const Icon(Icons.search)),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),
                    if (ps.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No matching projects.', textAlign: TextAlign.center)),
                    for (final p in ps) _ProjectCard(project: p),
                  ],
                ),
        );
      },
    );
  }
}

Future<void> showProjectDialog(BuildContext context, {Project? existing}) async {
  final name = TextEditingController(text: existing?.name ?? '');
  final address = TextEditingController(text: existing?.address ?? '');
  final client = TextEditingController(text: existing?.client ?? '');
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(existing == null ? 'NEW PROJECT' : 'EDIT PROJECT', style: const TextStyle(fontFamily: kMono, fontSize: 16)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, autofocus: true, textCapitalization: TextCapitalization.words, decoration: deco('Project name')),
            const SizedBox(height: 10),
            TextField(controller: address, textCapitalization: TextCapitalization.words, decoration: deco('Site address / location (optional)')),
            const SizedBox(height: 10),
            TextField(controller: client, textCapitalization: TextCapitalization.words, decoration: deco('Client / owner (optional)')),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
      ],
    ),
  );
  if (ok != true || name.text.trim().isEmpty) return;
  if (existing == null) {
    Store.i.projects.insert(0, Project(name: name.text.trim(), address: address.text.trim(), client: client.text.trim()));
  } else {
    existing
      ..name = name.text.trim()
      ..address = address.text.trim()
      ..client = client.text.trim();
  }
  await Store.i.save();
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({required this.project});
  final Project project;

  @override
  Widget build(BuildContext context) {
    final pct = overallPercent(project);
    final date = overallDate(project);
    final inspections = project.trades.fold<int>(0, (n, t) => n + t.inspections.length);
    final open = project.defects.where((d) => d.status == 'Open').length;
    return BpCard(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectScreen(project: project))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(project.name.toUpperCase(), style: const TextStyle(fontFamily: kMono, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'edit') {
                    await showProjectDialog(context, existing: project);
                  } else if (v == 'delete') {
                    if (await confirm(context, 'Delete project', 'Delete "${project.name}" with all its trades, photos and keyplans? This cannot be undone.')) {
                      await Store.i.deleteProject(project);
                    }
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Edit details')),
                  PopupMenuItem(value: 'delete', child: Text('Delete project')),
                ],
              ),
            ],
          ),
          if (project.address.isNotEmpty)
            Row(children: [
              const Icon(Icons.place, size: 14, color: kCyan),
              const SizedBox(width: 4),
              Expanded(child: Text(project.address, style: const TextStyle(fontSize: 13))),
            ]),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(pct == null ? '--' : fmtPct(pct), style: const TextStyle(fontFamily: kMono, fontSize: 24, color: kAccent, fontWeight: FontWeight.bold)),
              const SizedBox(width: 12),
              Expanded(
                child: LinearProgressIndicator(
                  value: (pct ?? 0) / 100,
                  minHeight: 8,
                  backgroundColor: kLine.withAlpha(40),
                  color: kAccent,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '${project.trades.length} trades  |  $inspections inspections  |  ${project.keyplans.length} keyplans'
            '${open > 0 ? '  |  $open open defects' : ''}'
            '${date == null ? '' : '  |  ${fmtDate(date)}'}',
            style: const TextStyle(fontSize: 12, color: kLine),
          ),
        ],
      ),
    );
  }
}
