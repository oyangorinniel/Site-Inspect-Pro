import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import 'models.dart';
import 'theme.dart';

String fmtDate(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String fmtDateTime(DateTime d) => DateFormat('dd MMM yyyy, hh:mm:ss a').format(d);
String fmtPct(double v) => '${v.toStringAsFixed(v % 1 == 0 ? 0 : 1)}%';

void toast(BuildContext c, String msg) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg)));

const kTradeSuggestions = [
  'Civil / Earthworks',
  'Structural',
  'Architectural',
  'Masonry',
  'Electrical',
  'Plumbing',
  'Mechanical / HVAC',
  'Fire Protection',
  'Roofing',
  'Waterproofing',
  'Painting',
  'Landscaping',
];

Future<String?> askText(
  BuildContext context,
  String title, {
  String initial = '',
  String hint = '',
  List<String> suggestions = const [],
  bool multiline = false,
  bool obscure = false,
  TextInputType? keyboard,
}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title.toUpperCase(), style: const TextStyle(fontFamily: kMono, fontSize: 16)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: c,
              autofocus: true,
              obscureText: obscure,
              maxLines: obscure ? 1 : (multiline ? 4 : 1),
              keyboardType: keyboard,
              textCapitalization: obscure ? TextCapitalization.none : TextCapitalization.sentences,
              decoration: deco(hint.isEmpty ? 'Name' : hint),
            ),
            if (suggestions.isNotEmpty) ...[
              const SizedBox(height: 12),
              const BpLabel('Quick pick'),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final s in suggestions)
                    ActionChip(
                      label: Text(s, style: const TextStyle(fontSize: 12)),
                      onPressed: () => c.text = s,
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('OK')),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context, String title, String msg, {String yes = 'Delete'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title.toUpperCase(), style: const TextStyle(fontFamily: kMono, fontSize: 16)),
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
      ],
    ),
  );
  return r ?? false;
}

Future<T> runWithLoader<T>(BuildContext context, String msg, Future<T> Function() job) async {
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        content: Row(
          children: [
            const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3)),
            const SizedBox(width: 16),
            Expanded(child: Text(msg)),
          ],
        ),
      ),
    ),
  );
  try {
    return await job();
  } finally {
    if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  }
}

/// Preset chips + a "Custom…" chip that reveals a free-text field.
class ChipPicker extends StatefulWidget {
  const ChipPicker({
    super.key,
    required this.presets,
    required this.value,
    required this.onChanged,
    this.customHint = 'Type your own',
  });

  final List<String> presets;
  final String value;
  final ValueChanged<String> onChanged;
  final String customHint;

  @override
  State<ChipPicker> createState() => _ChipPickerState();
}

class _ChipPickerState extends State<ChipPicker> {
  late bool custom;
  late TextEditingController c;

  @override
  void initState() {
    super.initState();
    custom = widget.value.isNotEmpty && !widget.presets.contains(widget.value);
    c = TextEditingController(text: custom ? widget.value : '');
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final s in widget.presets)
              bpChip(s, !custom && widget.value == s, () {
                setState(() => custom = false);
                widget.onChanged(s);
              }),
            bpChip('Custom…', custom, () {
              setState(() => custom = true);
              widget.onChanged(c.text.trim());
            }),
          ],
        ),
        if (custom)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: TextField(
              controller: c,
              textCapitalization: TextCapitalization.words,
              decoration: deco(widget.customHint),
              onChanged: (v) => widget.onChanged(v.trim()),
            ),
          ),
      ],
    );
  }
}

/// Microphone button: dictates into a text controller (appends to what is there).
class MicButton extends StatefulWidget {
  const MicButton({super.key, required this.controller, required this.onText});
  final TextEditingController controller;
  final ValueChanged<String> onText;

  @override
  State<MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<MicButton> {
  final stt.SpeechToText _s = stt.SpeechToText();
  bool _on = false;
  String _base = '';

  @override
  void dispose() {
    _s.cancel();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_on) {
      await _s.stop();
      if (mounted) setState(() => _on = false);
      return;
    }
    final ok = await _s.initialize(
      onStatus: (st) {
        if ((st == 'done' || st == 'notListening') && mounted) setState(() => _on = false);
      },
      onError: (_) {
        if (mounted) setState(() => _on = false);
      },
    );
    if (!ok) {
      if (mounted) toast(context, 'Voice input is not available on this phone');
      return;
    }
    _base = widget.controller.text;
    if (mounted) setState(() => _on = true);
    await _s.listen(onResult: (r) {
      final sep = _base.isEmpty || _base.endsWith(' ') ? '' : ' ';
      final t = '$_base$sep${r.recognizedWords}';
      widget.controller.text = t;
      widget.controller.selection = TextSelection.collapsed(offset: t.length);
      widget.onText(t);
    });
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'Dictate',
      onPressed: _toggle,
      icon: Icon(_on ? Icons.mic : Icons.mic_none, color: _on ? kBad : kCyan),
    );
  }
}

// ------------------------------------------------------ progress entries

Future<ProgressEntry?> showProgressDialog(
  BuildContext context, {
  ProgressEntry? existing,
  double suggest = 0,
  String title = 'PROGRESS',
}) {
  var date = existing?.date ?? DateTime.now();
  var pct = existing?.percent ?? suggest;
  final note = TextEditingController(text: existing?.note ?? '');
  final pctC = TextEditingController(text: pct.round().toString());
  return showDialog<ProgressEntry>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text(
          existing == null ? 'ADD $title' : 'EDIT $title',
          style: const TextStyle(fontFamily: kMono, fontSize: 16),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: date,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => date = d);
                  },
                  icon: const Icon(Icons.event),
                  label: Text('Date: ${fmtDate(date)}'),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Slider(
                      value: pct.clamp(0.0, 100.0).toDouble(),
                      min: 0,
                      max: 100,
                      divisions: 100,
                      label: '${pct.round()}%',
                      onChanged: (v) => setS(() {
                        pct = v;
                        pctC.text = v.round().toString();
                      }),
                    ),
                  ),
                  SizedBox(
                    width: 74,
                    child: TextField(
                      controller: pctC,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: deco('%'),
                      onChanged: (s) {
                        final v = double.tryParse(s);
                        if (v != null) setS(() => pct = v.clamp(0.0, 100.0).toDouble());
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              TextField(
                controller: note,
                textCapitalization: TextCapitalization.sentences,
                decoration: deco('Note (optional)'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(
              ctx,
              ProgressEntry(id: existing?.id, date: date, percent: pct, note: note.text.trim()),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    ),
  );
}

/// Progress summary + dated percentage log, newest first.
/// When [computed] is true the summary shows [valueOverride] / [dateOverride]
/// and the manual log is hidden (used for weighted projects).
class ProgressSection extends StatelessWidget {
  const ProgressSection({
    super.key,
    required this.entries,
    required this.onChanged,
    required this.heading,
    this.extra = const [],
    this.computed = false,
    this.valueOverride,
    this.dateOverride,
  });

  final List<ProgressEntry> entries;
  final VoidCallback onChanged;
  final String heading;
  final List<Widget> extra;
  final bool computed;
  final double? valueOverride;
  final DateTime? dateOverride;

  @override
  Widget build(BuildContext context) {
    final asc = sortedEntries(entries);
    final latest = latestEntry(entries);
    final pct = computed ? valueOverride : latest?.percent;
    final date = computed ? dateOverride : latest?.date;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        BpCard(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BpLabel(heading),
                    Text(
                      pct == null ? '--' : fmtPct(pct),
                      style: const TextStyle(fontFamily: kMono, fontSize: 38, fontWeight: FontWeight.bold, color: kAccent),
                    ),
                    Text(date == null ? 'No entries yet' : 'as of ${fmtDate(date)}'),
                  ],
                ),
              ),
              SizedBox(
                width: 64,
                height: 64,
                child: CircularProgressIndicator(
                  value: (pct ?? 0) / 100,
                  strokeWidth: 7,
                  backgroundColor: kLine.withAlpha(50),
                  color: kAccent,
                ),
              ),
            ],
          ),
        ),
        if (!computed)
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () async {
                final r = await showProgressDialog(context, suggest: latest?.percent ?? 0);
                if (r != null) {
                  entries.add(r);
                  onChanged();
                }
              },
              icon: const Icon(Icons.add),
              label: const Text('ADD DATE + PERCENTAGE'),
            ),
          ),
        const SizedBox(height: 12),
        ...extra,
        if (!computed)
          for (final e in asc.reversed)
            Builder(builder: (context) {
              final idx = asc.indexOf(e);
              final delta = idx > 0 ? e.percent - asc[idx - 1].percent : null;
              return BpCard(
                onTap: () async {
                  final r = await showProgressDialog(context, existing: e);
                  if (r != null) {
                    e
                      ..date = r.date
                      ..percent = r.percent
                      ..note = r.note;
                    onChanged();
                  }
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.event, size: 16, color: kCyan),
                        const SizedBox(width: 6),
                        Text(fmtDate(e.date), style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        if (delta != null)
                          Text(
                            '${delta >= 0 ? '+' : ''}${delta.toStringAsFixed(delta % 1 == 0 ? 0 : 1)}%  ',
                            style: TextStyle(color: delta >= 0 ? kGood : kBad, fontFamily: kMono, fontSize: 12),
                          ),
                        Text(fmtPct(e.percent), style: const TextStyle(fontFamily: kMono, fontSize: 18, color: kAccent)),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          icon: const Icon(Icons.delete_outline, size: 20),
                          onPressed: () async {
                            if (await confirm(context, 'Delete entry', 'Remove ${fmtDate(e.date)} (${fmtPct(e.percent)})?')) {
                              entries.remove(e);
                              onChanged();
                            }
                          },
                        ),
                      ],
                    ),
                    LinearProgressIndicator(
                      value: e.percent / 100,
                      minHeight: 6,
                      backgroundColor: kLine.withAlpha(40),
                      color: kAccent,
                    ),
                    if (e.note.isNotEmpty)
                      Padding(padding: const EdgeInsets.only(top: 6), child: Text(e.note, style: const TextStyle(fontSize: 13))),
                  ],
                ),
              );
            }),
      ],
    );
  }
}
