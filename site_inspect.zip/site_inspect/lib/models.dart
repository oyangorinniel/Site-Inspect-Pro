import 'dart:math';
import 'dart:ui' show Offset;

String newId() =>
    '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${Random().nextInt(46656).toRadixString(36)}';

double _d(dynamic v) => (v as num).toDouble();

DateTime? _dt(dynamic v) => v == null ? null : DateTime.parse(v as String);

List<T> _list<T>(dynamic v, T Function(Map<String, dynamic>) f) =>
    ((v ?? []) as List).map((e) => f(Map<String, dynamic>.from(e as Map))).toList();

// ---------------------------------------------------------------- progress

class ProgressEntry {
  String id;
  DateTime date;
  double percent;
  String note;

  ProgressEntry({String? id, required this.date, required this.percent, this.note = ''})
      : id = id ?? newId();

  Map<String, dynamic> toJson() =>
      {'id': id, 'date': date.toIso8601String(), 'percent': percent, 'note': note};

  factory ProgressEntry.fromJson(Map<String, dynamic> j) => ProgressEntry(
        id: j['id'],
        date: DateTime.parse(j['date']),
        percent: _d(j['percent']),
        note: j['note'] ?? '',
      );
}

ProgressEntry? latestEntry(List<ProgressEntry> l) {
  if (l.isEmpty) return null;
  var best = l.first;
  for (final e in l) {
    if (!e.date.isBefore(best.date)) best = e;
  }
  return best;
}

List<ProgressEntry> sortedEntries(List<ProgressEntry> l) =>
    [...l]..sort((a, b) => a.date.compareTo(b.date));

// ---------------------------------------------------------------- markups

enum MarkType { pin, arrow, circle, pen, text, rect, line }

/// Coordinates are normalised (0..1) against the image so they survive any
/// screen size. Weights and sizes are in a 400-unit reference width.
class Markup {
  String id;
  MarkType type;
  Offset p1;
  Offset p2;
  List<Offset> pts;
  int color;
  double weight;
  double size;
  int number;
  String text;

  Markup({
    String? id,
    required this.type,
    this.p1 = Offset.zero,
    Offset? p2,
    List<Offset>? pts,
    this.color = 0xFFFF3B30,
    this.weight = 3,
    this.size = 14,
    this.number = 1,
    this.text = '',
  })  : id = id ?? newId(),
        p2 = p2 ?? p1,
        pts = pts ?? [];

  void shift(double dx, double dy) {
    final d = Offset(dx, dy);
    p1 += d;
    p2 += d;
    pts = pts.map((o) => o + d).toList();
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'p1': [p1.dx, p1.dy],
        'p2': [p2.dx, p2.dy],
        'pts': pts.map((o) => [o.dx, o.dy]).toList(),
        'color': color,
        'weight': weight,
        'size': size,
        'number': number,
        'text': text,
      };

  factory Markup.fromJson(Map<String, dynamic> j) {
    Offset o(dynamic l) => Offset(_d(l[0]), _d(l[1]));
    return Markup(
      id: j['id'],
      type: MarkType.values.firstWhere((t) => t.name == j['type'], orElse: () => MarkType.pin),
      p1: o(j['p1']),
      p2: o(j['p2']),
      pts: ((j['pts'] ?? []) as List).map(o).toList(),
      color: j['color'] ?? 0xFFFF3B30,
      weight: _d(j['weight'] ?? 3),
      size: _d(j['size'] ?? 14),
      number: j['number'] ?? 1,
      text: j['text'] ?? '',
    );
  }
}

// ------------------------------------------------------------------ photos

class PhotoItem {
  String id;
  String file; // stamped (camera) or imported (gallery) image
  String? original; // untouched camera original, kept as evidence
  String caption;
  DateTime? takenAt;
  double? lat;
  double? lng;
  String address;
  bool fromGallery;
  List<Markup> markups;

  PhotoItem({
    String? id,
    required this.file,
    this.original,
    this.caption = '',
    this.takenAt,
    this.lat,
    this.lng,
    this.address = '',
    this.fromGallery = false,
    List<Markup>? markups,
  })  : id = id ?? newId(),
        markups = markups ?? [];

  Iterable<String> get allFiles sync* {
    yield file;
    if (original != null) yield original!;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'file': file,
        'original': original,
        'caption': caption,
        'takenAt': takenAt?.toIso8601String(),
        'lat': lat,
        'lng': lng,
        'address': address,
        'gallery': fromGallery,
        'markups': markups.map((e) => e.toJson()).toList(),
      };

  factory PhotoItem.fromJson(Map<String, dynamic> j) => PhotoItem(
        id: j['id'],
        file: j['file'],
        original: j['original'],
        caption: j['caption'] ?? '',
        takenAt: _dt(j['takenAt']),
        lat: j['lat'] == null ? null : _d(j['lat']),
        lng: j['lng'] == null ? null : _d(j['lng']),
        address: j['address'] ?? '',
        fromGallery: j['gallery'] ?? false,
        markups: _list(j['markups'], Markup.fromJson),
      );
}

// ------------------------------------------------------- signatures / lists

class SignBlock {
  String name;
  String? file;
  DateTime? date;

  SignBlock({this.name = '', this.file, this.date});

  Map<String, dynamic> toJson() => {'name': name, 'file': file, 'date': date?.toIso8601String()};

  factory SignBlock.fromJson(dynamic j) {
    if (j == null) return SignBlock();
    final m = Map<String, dynamic>.from(j as Map);
    return SignBlock(name: m['name'] ?? '', file: m['file'], date: _dt(m['date']));
  }
}

class CheckItem {
  String id;
  String text;
  String result; // '', 'Pass', 'Fail', 'N/A'
  String remark;

  CheckItem({String? id, required this.text, this.result = '', this.remark = ''}) : id = id ?? newId();

  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'result': result, 'remark': remark};

  factory CheckItem.fromJson(Map<String, dynamic> j) => CheckItem(
        id: j['id'],
        text: j['text'] ?? '',
        result: j['result'] ?? '',
        remark: j['remark'] ?? '',
      );
}

class ChecklistTemplate {
  String id;
  String name;
  List<String> items;

  ChecklistTemplate({String? id, required this.name, List<String>? items})
      : id = id ?? newId(),
        items = items ?? [];

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'items': items};

  factory ChecklistTemplate.fromJson(Map<String, dynamic> j) => ChecklistTemplate(
        id: j['id'],
        name: j['name'] ?? '',
        items: ((j['items'] ?? []) as List).map((e) => e.toString()).toList(),
      );
}

List<ChecklistTemplate> defaultTemplates() => [
      ChecklistTemplate(name: 'Rebar inspection', items: [
        'Bar size and spacing as per drawings',
        'Concrete cover and spacers in place',
        'Lap splice lengths',
        'Stirrups / ties spacing',
        'Formwork clean and free of debris',
      ]),
      ChecklistTemplate(name: 'Electrical rough-in', items: [
        'Conduit routing and supports',
        'Box locations and heights',
        'Wire sizes and color coding',
        'Grounding and bonding',
        'Labeling of circuits',
      ]),
      ChecklistTemplate(name: 'Plumbing pressure test', items: [
        'Pipe size and material as specified',
        'Pipe supports and slope',
        'Pressure test held for required duration',
        'No visible leaks at joints',
        'Fixtures and cleanouts accessible',
      ]),
    ];

// ------------------------------------------------------------- inspections

class Inspection {
  String id;
  DateTime date;
  String status;
  String notes;
  String inspectorName;
  String role;
  String company;
  List<PhotoItem> photos;
  List<CheckItem> checklist;
  SignBlock sigInspector;
  SignBlock sigContractor;
  SignBlock sigClient;

  Inspection({
    String? id,
    required this.date,
    this.status = 'Pending',
    this.notes = '',
    this.inspectorName = '',
    this.role = 'Inspector',
    this.company = '',
    List<PhotoItem>? photos,
    List<CheckItem>? checklist,
    SignBlock? sigInspector,
    SignBlock? sigContractor,
    SignBlock? sigClient,
  })  : id = id ?? newId(),
        photos = photos ?? [],
        checklist = checklist ?? [],
        sigInspector = sigInspector ?? SignBlock(),
        sigContractor = sigContractor ?? SignBlock(),
        sigClient = sigClient ?? SignBlock();

  Iterable<String> get allFiles sync* {
    for (final p in photos) {
      yield* p.allFiles;
    }
    for (final s in [sigInspector, sigContractor, sigClient]) {
      if (s.file != null) yield s.file!;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'status': status,
        'notes': notes,
        'name': inspectorName,
        'role': role,
        'company': company,
        'photos': photos.map((e) => e.toJson()).toList(),
        'checklist': checklist.map((e) => e.toJson()).toList(),
        'sigInspector': sigInspector.toJson(),
        'sigContractor': sigContractor.toJson(),
        'sigClient': sigClient.toJson(),
      };

  factory Inspection.fromJson(Map<String, dynamic> j) => Inspection(
        id: j['id'],
        date: DateTime.parse(j['date']),
        status: j['status'] ?? 'Pending',
        notes: j['notes'] ?? '',
        inspectorName: j['name'] ?? '',
        role: j['role'] ?? 'Inspector',
        company: j['company'] ?? '',
        photos: _list(j['photos'], PhotoItem.fromJson),
        checklist: _list(j['checklist'], CheckItem.fromJson),
        sigInspector: SignBlock.fromJson(j['sigInspector']),
        sigContractor: SignBlock.fromJson(j['sigContractor']),
        sigClient: SignBlock.fromJson(j['sigClient']),
      );
}

class Trade {
  String id;
  String name;
  double weight;
  List<ProgressEntry> progress;
  List<Inspection> inspections;

  Trade({
    String? id,
    required this.name,
    this.weight = 1,
    List<ProgressEntry>? progress,
    List<Inspection>? inspections,
  })  : id = id ?? newId(),
        progress = progress ?? [],
        inspections = inspections ?? [];

  Iterable<String> get allFiles sync* {
    for (final i in inspections) {
      yield* i.allFiles;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'weight': weight,
        'progress': progress.map((e) => e.toJson()).toList(),
        'inspections': inspections.map((e) => e.toJson()).toList(),
      };

  factory Trade.fromJson(Map<String, dynamic> j) => Trade(
        id: j['id'],
        name: j['name'],
        weight: j['weight'] == null ? 1 : _d(j['weight']),
        progress: _list(j['progress'], ProgressEntry.fromJson),
        inspections: _list(j['inspections'], Inspection.fromJson),
      );
}

// ---------------------------------------------------------------- keyplans

class Keyplan {
  String id;
  String name;
  String file;
  List<Markup> markups;

  Keyplan({String? id, required this.name, required this.file, List<Markup>? markups})
      : id = id ?? newId(),
        markups = markups ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'file': file,
        'markups': markups.map((e) => e.toJson()).toList(),
      };

  factory Keyplan.fromJson(Map<String, dynamic> j) => Keyplan(
        id: j['id'],
        name: j['name'],
        file: j['file'],
        markups: _list(j['markups'], Markup.fromJson),
      );
}

// ------------------------------------------------------------ punch list

class Defect {
  String id;
  String no;
  String title;
  String desc;
  String location;
  String trade;
  String responsible;
  DateTime? due;
  String status; // Open, Fixed, Verified (or custom)
  DateTime createdAt;
  PhotoItem? before;
  PhotoItem? after;
  String? keyplanId;
  int? pin;

  Defect({
    String? id,
    required this.no,
    this.title = '',
    this.desc = '',
    this.location = '',
    this.trade = '',
    this.responsible = '',
    this.due,
    this.status = 'Open',
    DateTime? createdAt,
    this.before,
    this.after,
    this.keyplanId,
    this.pin,
  })  : id = id ?? newId(),
        createdAt = createdAt ?? DateTime.now();

  Iterable<String> get allFiles sync* {
    if (before != null) yield* before!.allFiles;
    if (after != null) yield* after!.allFiles;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'no': no,
        'title': title,
        'desc': desc,
        'location': location,
        'trade': trade,
        'responsible': responsible,
        'due': due?.toIso8601String(),
        'status': status,
        'createdAt': createdAt.toIso8601String(),
        'before': before?.toJson(),
        'after': after?.toJson(),
        'keyplanId': keyplanId,
        'pin': pin,
      };

  factory Defect.fromJson(Map<String, dynamic> j) => Defect(
        id: j['id'],
        no: j['no'] ?? '',
        title: j['title'] ?? '',
        desc: j['desc'] ?? '',
        location: j['location'] ?? '',
        trade: j['trade'] ?? '',
        responsible: j['responsible'] ?? '',
        due: _dt(j['due']),
        status: j['status'] ?? 'Open',
        createdAt: _dt(j['createdAt']),
        before: j['before'] == null ? null : PhotoItem.fromJson(Map<String, dynamic>.from(j['before'] as Map)),
        after: j['after'] == null ? null : PhotoItem.fromJson(Map<String, dynamic>.from(j['after'] as Map)),
        keyplanId: j['keyplanId'],
        pin: j['pin'],
      );
}

// --------------------------------------------------------- daily site log

class ManpowerItem {
  String label;
  int count;

  ManpowerItem({required this.label, this.count = 1});

  Map<String, dynamic> toJson() => {'label': label, 'count': count};

  factory ManpowerItem.fromJson(Map<String, dynamic> j) =>
      ManpowerItem(label: j['label'] ?? '', count: (j['count'] ?? 0) as int);
}

class SiteLog {
  String id;
  DateTime date;
  String weather;
  String temp;
  List<ManpowerItem> manpower;
  String equipment;
  String delays;
  String notes;

  SiteLog({
    String? id,
    required this.date,
    this.weather = '',
    this.temp = '',
    List<ManpowerItem>? manpower,
    this.equipment = '',
    this.delays = '',
    this.notes = '',
  })  : id = id ?? newId(),
        manpower = manpower ?? [];

  int get totalManpower => manpower.fold(0, (n, m) => n + m.count);

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'weather': weather,
        'temp': temp,
        'manpower': manpower.map((e) => e.toJson()).toList(),
        'equipment': equipment,
        'delays': delays,
        'notes': notes,
      };

  factory SiteLog.fromJson(Map<String, dynamic> j) => SiteLog(
        id: j['id'],
        date: DateTime.parse(j['date']),
        weather: j['weather'] ?? '',
        temp: j['temp'] ?? '',
        manpower: _list(j['manpower'], ManpowerItem.fromJson),
        equipment: j['equipment'] ?? '',
        delays: j['delays'] ?? '',
        notes: j['notes'] ?? '',
      );
}

// ---------------------------------------------------------------- projects

class Project {
  String id;
  String name;
  String address;
  String client;
  DateTime createdAt;
  bool weighted;
  int defectSeq;
  int reportSeq;
  List<ProgressEntry> progress;
  List<ProgressEntry> planned;
  List<Trade> trades;
  List<Keyplan> keyplans;
  List<Defect> defects;
  List<SiteLog> logs;

  Project({
    String? id,
    required this.name,
    this.address = '',
    this.client = '',
    DateTime? createdAt,
    this.weighted = false,
    this.defectSeq = 0,
    this.reportSeq = 0,
    List<ProgressEntry>? progress,
    List<ProgressEntry>? planned,
    List<Trade>? trades,
    List<Keyplan>? keyplans,
    List<Defect>? defects,
    List<SiteLog>? logs,
  })  : id = id ?? newId(),
        createdAt = createdAt ?? DateTime.now(),
        progress = progress ?? [],
        planned = planned ?? [],
        trades = trades ?? [],
        keyplans = keyplans ?? [],
        defects = defects ?? [],
        logs = logs ?? [];

  Iterable<String> get mediaFiles sync* {
    for (final t in trades) {
      yield* t.allFiles;
    }
    for (final k in keyplans) {
      yield k.file;
    }
    for (final d in defects) {
      yield* d.allFiles;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'address': address,
        'client': client,
        'createdAt': createdAt.toIso8601String(),
        'weighted': weighted,
        'defectSeq': defectSeq,
        'reportSeq': reportSeq,
        'progress': progress.map((e) => e.toJson()).toList(),
        'planned': planned.map((e) => e.toJson()).toList(),
        'trades': trades.map((e) => e.toJson()).toList(),
        'keyplans': keyplans.map((e) => e.toJson()).toList(),
        'defects': defects.map((e) => e.toJson()).toList(),
        'logs': logs.map((e) => e.toJson()).toList(),
      };

  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'],
        name: j['name'],
        address: j['address'] ?? '',
        client: j['client'] ?? '',
        createdAt: DateTime.parse(j['createdAt']),
        weighted: j['weighted'] ?? false,
        defectSeq: j['defectSeq'] ?? 0,
        reportSeq: j['reportSeq'] ?? 0,
        progress: _list(j['progress'], ProgressEntry.fromJson),
        planned: _list(j['planned'], ProgressEntry.fromJson),
        trades: _list(j['trades'], Trade.fromJson),
        keyplans: _list(j['keyplans'], Keyplan.fromJson),
        defects: _list(j['defects'], Defect.fromJson),
        logs: _list(j['logs'], SiteLog.fromJson),
      );
}

// ---------------------------------------------------------------- settings

class AppSettings {
  String lastName;
  String lastRole;
  String lastCompany;
  bool stampProject;
  String? logoFile;
  String license;
  String contact;
  String footer;
  int accent;
  String? pinHash;
  String? mySig;
  DateTime? lastBackup;

  AppSettings({
    this.lastName = '',
    this.lastRole = 'Inspector',
    this.lastCompany = '',
    this.stampProject = true,
    this.logoFile,
    this.license = '',
    this.contact = '',
    this.footer = '',
    this.accent = 0xFF0F3D73,
    this.pinHash,
    this.mySig,
    this.lastBackup,
  });

  Map<String, dynamic> toJson() => {
        'lastName': lastName,
        'lastRole': lastRole,
        'lastCompany': lastCompany,
        'stampProject': stampProject,
        'logoFile': logoFile,
        'license': license,
        'contact': contact,
        'footer': footer,
        'accent': accent,
        'pinHash': pinHash,
        'mySig': mySig,
        'lastBackup': lastBackup?.toIso8601String(),
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        lastName: j['lastName'] ?? '',
        lastRole: j['lastRole'] ?? 'Inspector',
        lastCompany: j['lastCompany'] ?? '',
        stampProject: j['stampProject'] ?? true,
        logoFile: j['logoFile'],
        license: j['license'] ?? '',
        contact: j['contact'] ?? '',
        footer: j['footer'] ?? '',
        accent: j['accent'] ?? 0xFF0F3D73,
        pinHash: j['pinHash'],
        mySig: j['mySig'],
        lastBackup: _dt(j['lastBackup']),
      );
}
