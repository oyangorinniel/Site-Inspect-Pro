import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'models.dart';

/// Reference width that line weights / sizes are expressed in. The painter
/// scales them to whatever size it draws at (screen or exported image).
const double kRef = 400;

Offset px(Offset n, Size sz) => Offset(n.dx * sz.width, n.dy * sz.height);

TextPainter _tp(String t, double fs, Color col) => TextPainter(
      text: TextSpan(text: t, style: TextStyle(color: col, fontSize: fs, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    )..layout();

class KeyplanPainter extends CustomPainter {
  KeyplanPainter({required this.image, required this.items, this.selectedId});

  final ui.Image? image;
  final List<Markup> items;
  final String? selectedId;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    final im = image;
    if (im != null) {
      canvas.drawImageRect(
        im,
        Rect.fromLTWH(0, 0, im.width.toDouble(), im.height.toDouble()),
        Offset.zero & size,
        Paint()..filterQuality = FilterQuality.high,
      );
    }
    final s = size.width / kRef;
    for (final mk in items) {
      drawMarkup(canvas, size, s, mk);
    }
    if (selectedId != null) {
      for (final mk in items) {
        if (mk.id == selectedId) drawSelection(canvas, size, s, mk);
      }
    }
  }

  @override
  bool shouldRepaint(covariant KeyplanPainter oldDelegate) => true;
}

void drawMarkup(Canvas c, Size sz, double s, Markup mk) {
  final col = Color(mk.color);
  final stroke = Paint()
    ..color = col
    ..style = PaintingStyle.stroke
    ..strokeWidth = mk.weight * s
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;
  final a = px(mk.p1, sz);
  final b = px(mk.p2, sz);

  switch (mk.type) {
    case MarkType.pin:
      {
        final r = mk.size * s;
        c.drawCircle(a + Offset(1.5 * s, 1.5 * s), r, Paint()..color = Colors.black38);
        c.drawCircle(a, r, Paint()..color = col);
        c.drawCircle(
          a,
          r,
          Paint()
            ..color = Colors.white
            ..style = PaintingStyle.stroke
            ..strokeWidth = math.max(1.5 * s, r * 0.12),
        );
        final tc = col.computeLuminance() > 0.6 ? Colors.black : Colors.white;
        final tp = _tp('${mk.number}', r * 1.1, tc);
        tp.paint(c, a - Offset(tp.width / 2, tp.height / 2));
      }
    case MarkType.arrow:
      {
        c.drawLine(a, b, stroke);
        final ang = math.atan2(b.dy - a.dy, b.dx - a.dx);
        final hl = (mk.weight * 3 + 10) * s;
        for (final d in [0.5, -0.5]) {
          c.drawLine(b, b - Offset(math.cos(ang + d), math.sin(ang + d)) * hl, stroke);
        }
      }
    case MarkType.line:
      c.drawLine(a, b, stroke);
    case MarkType.circle:
      c.drawCircle(a, (b - a).distance, stroke);
    case MarkType.rect:
      c.drawRect(Rect.fromPoints(a, b), stroke);
    case MarkType.pen:
      {
        if (mk.pts.isEmpty) break;
        if (mk.pts.length == 1) {
          c.drawCircle(px(mk.pts.first, sz), mk.weight * s / 2, Paint()..color = col);
          break;
        }
        final path = Path()..moveTo(px(mk.pts.first, sz).dx, px(mk.pts.first, sz).dy);
        for (var i = 1; i < mk.pts.length; i++) {
          final q = px(mk.pts[i], sz);
          path.lineTo(q.dx, q.dy);
        }
        c.drawPath(path, stroke);
      }
    case MarkType.text:
      {
        final tp = _tp(mk.text, mk.size * s, col);
        final bg = col.computeLuminance() > 0.6 ? Colors.black.withAlpha(150) : Colors.white.withAlpha(210);
        final r = Rect.fromLTWH(a.dx, a.dy, tp.width, tp.height).inflate(3 * s);
        c.drawRRect(RRect.fromRectAndRadius(r, Radius.circular(2 * s)), Paint()..color = bg);
        tp.paint(c, a);
      }
  }
}

Rect boundsPx(Markup mk, Size sz, double s) {
  final a = px(mk.p1, sz);
  final b = px(mk.p2, sz);
  switch (mk.type) {
    case MarkType.pin:
      return Rect.fromCircle(center: a, radius: mk.size * s);
    case MarkType.text:
      final tp = _tp(mk.text, mk.size * s, Colors.black);
      return Rect.fromLTWH(a.dx, a.dy, tp.width, tp.height);
    case MarkType.arrow:
    case MarkType.line:
    case MarkType.rect:
      return Rect.fromPoints(a, b);
    case MarkType.circle:
      return Rect.fromCircle(center: a, radius: (b - a).distance);
    case MarkType.pen:
      if (mk.pts.isEmpty) return Rect.fromCircle(center: a, radius: 4 * s);
      var r = Rect.fromPoints(px(mk.pts.first, sz), px(mk.pts.first, sz));
      for (final q in mk.pts) {
        final o = px(q, sz);
        r = Rect.fromLTRB(math.min(r.left, o.dx), math.min(r.top, o.dy), math.max(r.right, o.dx), math.max(r.bottom, o.dy));
      }
      return r;
  }
}

/// Draggable handles: (1 = first point, 2 = second point / radius).
List<(int, Offset)> handlesPx(Markup mk, Size sz) {
  final a = px(mk.p1, sz);
  final b = px(mk.p2, sz);
  switch (mk.type) {
    case MarkType.arrow:
    case MarkType.line:
    case MarkType.rect:
      return [(1, a), (2, b)];
    case MarkType.circle:
      return [(2, b)];
    default:
      return const [];
  }
}

void drawSelection(Canvas c, Size sz, double s, Markup mk) {
  final box = boundsPx(mk, sz, s).inflate(6 * s);
  final p = Paint()
    ..color = const Color(0xFF00E5FF)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.2 * s;
  c.drawRect(box, p);
  for (final h in handlesPx(mk, sz)) {
    c.drawCircle(h.$2, 8 * s, Paint()..color = Colors.white);
    c.drawCircle(h.$2, 8 * s, p..strokeWidth = 2 * s);
  }
}

double _seg(Offset p, Offset a, Offset b) {
  final ab = b - a;
  final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
  if (len2 == 0) return (p - a).distance;
  final t = (((p.dx - a.dx) * ab.dx + (p.dy - a.dy) * ab.dy) / len2).clamp(0.0, 1.0).toDouble();
  return (p - (a + ab * t)).distance;
}

bool hitMarkup(Markup mk, Offset pos, Size sz, double s) {
  final tol = math.max(12.0, mk.weight * s * 1.2 + 8);
  final a = px(mk.p1, sz);
  final b = px(mk.p2, sz);
  switch (mk.type) {
    case MarkType.pin:
      return (pos - a).distance <= mk.size * s + 8;
    case MarkType.text:
      return boundsPx(mk, sz, s).inflate(8).contains(pos);
    case MarkType.arrow:
    case MarkType.line:
      return _seg(pos, a, b) <= tol;
    case MarkType.circle:
      return ((pos - a).distance - (b - a).distance).abs() <= tol;
    case MarkType.rect:
      final r = Rect.fromPoints(a, b);
      final cs = [r.topLeft, r.topRight, r.bottomRight, r.bottomLeft];
      for (var i = 0; i < 4; i++) {
        if (_seg(pos, cs[i], cs[(i + 1) % 4]) <= tol) return true;
      }
      return false;
    case MarkType.pen:
      for (var i = 0; i < mk.pts.length; i++) {
        final q = px(mk.pts[i], sz);
        if (mk.pts.length == 1 && (pos - q).distance <= tol) return true;
        if (i > 0 && _seg(pos, px(mk.pts[i - 1], sz), q) <= tol) return true;
      }
      return false;
  }
}

/// Renders the keyplan with its markups to a PNG (used by the PDF report).
Future<Uint8List?> renderKeyplanPng(String path, List<Markup> items, {int maxW = 1800}) async {
  final bytes = await File(path).readAsBytes();
  final im = await decodeImageFromList(bytes);
  final scale = math.min(1.0, maxW / im.width);
  final w = (im.width * scale).round();
  final h = (im.height * scale).round();
  final rec = ui.PictureRecorder();
  final canvas = Canvas(rec);
  KeyplanPainter(image: im, items: items).paint(canvas, Size(w.toDouble(), h.toDouble()));
  final out = await rec.endRecording().toImage(w, h);
  final bd = await out.toByteData(format: ui.ImageByteFormat.png);
  im.dispose();
  return bd?.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
}
