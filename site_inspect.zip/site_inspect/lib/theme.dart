import 'package:flutter/material.dart';

// Blueprint palette (interface only; exported reports stay plain white).
const kBlue = Color(0xFF0F3D73);
const kBlueDark = Color(0xFF0A2C55);
const kBlueDeep = Color(0xFF071F3D);
const kLine = Color(0xFF8CC4FF);
const kPaper = Color(0xFFEAF4FF);
const kAccent = Color(0xFFFFD34E);
const kCyan = Color(0xFF6FE3FF);
const kGood = Color(0xFF5BE49B);
const kBad = Color(0xFFFF6B6B);
const kMono = 'monospace';

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    primary: kAccent,
    onPrimary: Colors.black,
    secondary: kCyan,
    onSecondary: Colors.black,
    surface: kBlueDark,
    onSurface: kPaper,
    error: kBad,
    outline: kLine,
    surfaceContainer: kBlueDark,
    surfaceContainerHigh: kBlueDark,
    surfaceContainerHighest: kBlueDeep,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: kBlue,
  );
}

class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF12467F), kBlue],
        ).createShader(rect),
    );
    final minor = Paint()
      ..color = kLine.withAlpha(24)
      ..strokeWidth = 0.6;
    final major = Paint()
      ..color = kLine.withAlpha(56)
      ..strokeWidth = 1;
    const step = 20.0;
    var i = 0;
    for (double x = 0; x <= size.width; x += step, i++) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), i % 5 == 0 ? major : minor);
    }
    i = 0;
    for (double y = 0; y <= size.height; y += step, i++) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), i % 5 == 0 ? major : minor);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Screen wrapper: blueprint grid background + engineering-style app bar.
class BpScaffold extends StatelessWidget {
  const BpScaffold({
    super.key,
    required this.title,
    required this.body,
    this.actions = const [],
    this.bottom,
    this.fab,
    this.bottomBar,
  });

  final String title;
  final Widget body;
  final List<Widget> actions;
  final PreferredSizeWidget? bottom;
  final Widget? fab;
  final Widget? bottomBar;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(child: RepaintBoundary(child: CustomPaint(painter: _GridPainter()))),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            title: Text(
              title.toUpperCase(),
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.bold, letterSpacing: 1.2, fontSize: 17),
            ),
            backgroundColor: kBlueDeep.withAlpha(235),
            foregroundColor: kPaper,
            elevation: 0,
            scrolledUnderElevation: 0,
            shape: Border(bottom: BorderSide(color: kLine.withAlpha(130))),
            actions: actions,
            bottom: bottom,
          ),
          body: body,
          floatingActionButton: fab,
          bottomNavigationBar: bottomBar,
        ),
      ],
    );
  }
}

class BpCard extends StatelessWidget {
  const BpCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(12),
    this.margin = const EdgeInsets.only(bottom: 10),
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final EdgeInsets margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin,
      child: Material(
        color: kBlueDeep.withAlpha(205),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(3),
          side: BorderSide(color: kLine.withAlpha(150)),
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(3),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class BpLabel extends StatelessWidget {
  const BpLabel(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(fontFamily: kMono, fontSize: 11, letterSpacing: 1.4, color: kCyan, fontWeight: FontWeight.bold),
        ),
      );
}

InputDecoration deco(String label, {String? hint, Widget? suffix}) {
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(3),
    borderSide: BorderSide(color: kLine.withAlpha(150)),
  );
  return InputDecoration(
    labelText: label,
    hintText: hint,
    suffixIcon: suffix,
    isDense: true,
    filled: true,
    fillColor: kBlueDeep.withAlpha(170),
    border: border,
    enabledBorder: border,
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(3),
      borderSide: const BorderSide(color: kAccent, width: 1.5),
    ),
    labelStyle: const TextStyle(color: kLine),
  );
}

Widget bpChip(String label, bool selected, VoidCallback onTap) => ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: kAccent,
      backgroundColor: kBlueDeep.withAlpha(200),
      showCheckmark: false,
      labelStyle: TextStyle(color: selected ? Colors.black : kPaper, fontWeight: FontWeight.w600),
      side: BorderSide(color: selected ? kAccent : kLine.withAlpha(150)),
    );
