import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:exif/exif.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;

import 'models.dart';
import 'store.dart';
import 'widgets.dart';

Uint8List _encodeJpgJob(Map<String, dynamic> a) {
  final im = img.Image.fromBytes(
    width: a['w'] as int,
    height: a['h'] as int,
    bytes: (a['rgba'] as Uint8List).buffer,
    numChannels: 4,
  );
  return Uint8List.fromList(img.encodeJpg(im, quality: 88));
}

class PhotoService {
  /// Starts a GPS lookup. Never throws; resolves to null when unavailable.
  static Future<Position?> currentPosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      try {
        return await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12)),
        );
      } catch (_) {
        return await Geolocator.getLastKnownPosition();
      }
    } catch (_) {
      return null;
    }
  }

  /// Street address for a coordinate (needs internet). Empty string if unknown.
  static Future<String> addressOf(double lat, double lng) async {
    try {
      final list = await placemarkFromCoordinates(lat, lng).timeout(const Duration(seconds: 4));
      if (list.isEmpty) return '';
      final m = list.first;
      final parts = <String>[];
      for (final s in [m.street, m.subLocality, m.locality, m.administrativeArea]) {
        final t = (s ?? '').trim();
        if (t.isNotEmpty && !parts.contains(t)) parts.add(t);
      }
      return parts.join(', ');
    } catch (_) {
      return '';
    }
  }

  static Future<XFile?> openCamera() =>
      ImagePicker().pickImage(source: ImageSource.camera, maxWidth: 2560, maxHeight: 2560, imageQuality: 92);

  /// Burns date/time, project name (optional), address and GPS into the photo
  /// and saves it. The untouched original is also kept when [keepOriginal].
  static Future<PhotoItem> processCapture(
    XFile x, {
    required Future<Position?> position,
    String? projectName,
    bool keepOriginal = true,
  }) async {
    final taken = DateTime.now();
    final pos = await position;
    final bytes = await x.readAsBytes();
    var address = '';
    if (pos != null) address = await addressOf(pos.latitude, pos.longitude);
    final lines = <String>[
      fmtDateTime(taken),
      if (projectName != null && projectName.trim().isNotEmpty) projectName.trim(),
      if (address.isNotEmpty) address,
      pos == null
          ? 'Location unavailable'
          : 'Lat ${pos.latitude.toStringAsFixed(6)}  Lng ${pos.longitude.toStringAsFixed(6)}',
    ];
    final jpg = await _stampJpeg(bytes, lines);
    final name = await Store.i.addMediaBytes(jpg, 'jpg');
    String? orig;
    if (keepOriginal) orig = await Store.i.addMediaBytes(bytes, 'jpg');
    return PhotoItem(
      file: name,
      original: orig,
      takenAt: taken,
      lat: pos?.latitude,
      lng: pos?.longitude,
      address: address,
    );
  }

  static Future<Uint8List> _stampJpeg(Uint8List bytes, List<String> lines) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final src = frame.image;
    final w = src.width.toDouble();
    final h = src.height.toDouble();
    final scale = min(1.0, 1920 / max(w, h));
    final tw = (w * scale).round();
    final th = (h * scale).round();

    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    canvas.drawImageRect(
      src,
      Rect.fromLTWH(0, 0, w, h),
      Rect.fromLTWH(0, 0, tw.toDouble(), th.toDouble()),
      Paint()..filterQuality = FilterQuality.high,
    );

    final fs = min(tw, th) / 30;
    final pad = fs * 0.6;
    final tp = TextPainter(
      text: TextSpan(
        text: lines.join('\n'),
        style: TextStyle(color: Colors.white, fontSize: fs, fontWeight: FontWeight.w600, height: 1.25),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: tw - pad * 2);
    final box = Rect.fromLTWH(0, th - tp.height - pad * 2, min(tw.toDouble(), tp.width + pad * 2), tp.height + pad * 2);
    canvas.drawRect(box, Paint()..color = Colors.black.withAlpha(150));
    tp.paint(canvas, Offset(pad, box.top + pad));

    final out = await rec.endRecording().toImage(tw, th);
    final bd = await out.toByteData(format: ui.ImageByteFormat.rawRgba);
    src.dispose();
    final rgba = bd!.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
    return compute(_encodeJpgJob, {'w': tw, 'h': th, 'rgba': rgba});
  }

  /// Imports gallery photos, keeping the original file and reading its own
  /// date / GPS when present (no stamp is added).
  static Future<List<PhotoItem>> importFromGallery({bool multi = true}) async {
    final picker = ImagePicker();
    final List<XFile> files;
    if (multi) {
      files = await picker.pickMultiImage();
    } else {
      final one = await picker.pickImage(source: ImageSource.gallery);
      files = one == null ? <XFile>[] : [one];
    }
    final result = <PhotoItem>[];
    for (final x in files) {
      final bytes = await x.readAsBytes();
      var ext = p.extension(x.path).replaceFirst('.', '').toLowerCase();
      if (ext.isEmpty || ext.length > 4) ext = 'jpg';
      final name = await Store.i.addMediaBytes(bytes, ext);
      DateTime? when;
      double? lat;
      double? lng;
      try {
        final tags = await readExifFromBytes(bytes);
        final raw = (tags['EXIF DateTimeOriginal'] ?? tags['Image DateTime'])?.printable;
        if (raw != null && raw.length >= 19) {
          final d = raw.substring(0, 10).replaceAll(':', '-');
          when = DateTime.tryParse('$d ${raw.substring(11, 19)}');
        }
        lat = _gps(tags, 'GPS GPSLatitude', 'GPS GPSLatitudeRef');
        lng = _gps(tags, 'GPS GPSLongitude', 'GPS GPSLongitudeRef');
      } catch (_) {}
      result.add(PhotoItem(file: name, takenAt: when, lat: lat, lng: lng, fromGallery: true));
    }
    return result;
  }

  static double? _gps(Map<String, IfdTag> tags, String key, String refKey) {
    try {
      final tag = tags[key];
      final ref = tags[refKey]?.printable;
      if (tag == null || ref == null) return null;
      final ratios = (tag.values as dynamic).ratios as List;
      if (ratios.length < 3) return null;
      double r(dynamic x) => (x.numerator as num) / (x.denominator as num);
      var v = r(ratios[0]) + r(ratios[1]) / 60 + r(ratios[2]) / 3600;
      if (ref == 'S' || ref == 'W') v = -v;
      return v;
    } catch (_) {
      return null;
    }
  }
}
