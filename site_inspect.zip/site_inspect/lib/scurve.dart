import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'calc.dart';
import 'theme.dart';

/// Planned vs actual progress chart. `dark` = app look, otherwise white
/// background for the PDF report.
class SCurvePainter extends CustomPainter {
  SCurvePainter({required this.planned, required this.actual, this.dark = true});

  final List<Pt> planned;
  final List<Pt> actual;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / 360;
    final txt = dark ? kPaper : const Color(0xFF222222);
    final grid = dark ? kLine.withAlpha(70) : const Color(0xFFBBBBBB);
    final cPlan = dark ? kCyan : const Color(0xFF1565C0);
    final cAct = dark ? kAccent : const Color(0xFFE65100);
    if (!dark) canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);

    TextPainter tp(String s, double fs) => TextPainter(
          text: TextSpan(text: s, style: TextStyle(color: txt, fontSize: fs * k)),
          textDirection: TextDirection.ltr,
        )..layout();

    final r = Rect.fromLTRB(34 * k, 8 * k, size.width - 10 * k, size.height - 22 * k);
    final all = [...planned, ...actual];
    if (all.isEmpty) {
      final t = tp('No data yet', 12);
      t.paint(canvas, r.center - Offset(t.width / 2, t.height / 2));
      return;
    }

    var minD = all.first.date;
    var maxD = all.first.date;
    for (final p in all) {
      if (p.date.isBefore(minD)) minD = p.date;
      if (p.date.isAfter(maxD)) maxD = p.date;
    }
    var span = maxD.difference(minD).inDays;
    if (span < 1) span = 1;

    double xOf(DateTime d) => r.left + r.width * (d.difference(minD).inDays / span);
    double yOf(double v) => r.bottom - r.height * (v.clamp(0.0, 100.0).toDouble() / 100);

    final gp = Paint()
      ..color = grid
      ..strokeWidth = 1 * k;
    for (final v in [0, 25, 50, 75, 100]) {
      final y = yOf(v.toDouble());
      canvas.drawLine(Offset(r.left, y), Offset(r.right, y), gp);
      final t = tp('$v%', 9);
      t.paint(canvas, Offset(r.left - t.width - 4 * k, y - t.height / 2));
    }

    final df = DateFormat('dd MMM');
    final labels = <DateTime>[minD, maxD];
    if (span >= 4) labels.insert(1, minD.add(Duration(days: span ~/ 2)));
    for (var i = 0; i < labels.length; i++) {
      final t = tp(df.format(labels[i]), 9);
      var x = xOf(labels[i]) - t.width / 2;
      if (x < 0) x = 0;
      if (x + t.width > size.width) x = size.width - t.width;
      t.paint(canvas, Offset(x, r.bottom + 4 * k));
    }

    void drawSeries(List<Pt> pts, Color c, {required bool dashed}) {
      if (pts.isEmpty) return;
      final path = Path();
      for (var i = 0; i < pts.length; i++) {
        final o = Offset(xOf(pts[i].date), yOf(pts[i].pct));
        if (i == 0) {
          path.moveTo(o.dx, o.dy);
        } else {
          path.lineTo(o.dx, o.dy);
        }
      }
      final paint = Paint()
        ..color = c
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2 * k
        ..strokeJoin = StrokeJoin.round;
      if (!dashed) {
        canvas.drawPath(path, paint);
      } else {
        for (final m in path.computeMetrics()) {
          var d = 0.0;
          while (d < m.length) {
            canvas.drawPath(m.extractPath(d, d + 6 * k), paint);
            d += 11 * k;
          }
        }
      }
      for (final p in pts) {
        canvas.drawCircle(Offset(xOf(p.date), yOf(p.pct)), 3 * k, Paint()..color = c);
      }
    }

    drawSeries(planned, cPlan, dashed: true);
    drawSeries(actual, cAct, dashed: false);
  }

  @override
  bool shouldRepaint(covariant SCurvePainter old) => true;
}

Future<Uint8List?> renderSCurvePng(List<Pt> planned, List<Pt> actual) async {
  const w = 1080.0;
  const h = 480.0;
  final rec = ui.PictureRecorder();
  SCurvePainter(planned: planned, actual: actual, dark: false).paint(Canvas(rec), const Size(w, h));
  final im = await rec.endRecording().toImage(w.toInt(), h.toInt());
  final bd = await im.toByteData(format: ui.ImageByteFormat.png);
  return bd?.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
}
