import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'screens/lock_screen.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.i.init();
  runApp(const SiteInspectApp());
}

class SiteInspectApp extends StatelessWidget {
  const SiteInspectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Site Inspect',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) => LockGate(child: child ?? const SizedBox.shrink()),
      home: const HomeScreen(),
    );
  }
}
