import 'dart:io';

import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../calc.dart';
import '../models.dart';
import '../store.dart';
import 'report_options.dart';

String _d(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String _dt(DateTime d) => DateFormat('dd MMM yyyy hh:mm a').format(d);

CellValue? _cv(dynamic v) {
  if (v == null) return null;
  if (v is int) return IntCellValue(v);
  if (v is double) return DoubleCellValue(v);
  return TextCellValue(v.toString());
}

void _row(Sheet s, List<dynamic> vals, {bool bold = false}) {
  s.appendRow(vals.map(_cv).toList());
  if (bold) {
    final r = s.maxRows - 1;
    for (var c = 0; c < vals.length; c++) {
      s.cell(CellIndex.indexByColumnRow(columnIndex: c, rowIndex: r)).cellStyle = CellStyle(bold: true);
    }
  }
}

void _widths(Sheet s, List<double> w) {
  for (var i = 0; i < w.length; i++) {
    s.setColumnWidth(i, w[i]);
  }
}

Future<File> buildExcel(Project pr, ReportOptions o) async {
  final st = Store.i.settings;
  final now = DateTime.now();
  final ex = Excel.createExcel();
  ex.rename('Sheet1', 'Summary');

  // ---------------------------------------------------------------- summary
  final sum = ex['Summary'];
  _widths(sum, [22, 40, 14, 40]);
  _row(sum, ['INSPECTION PROGRESS REPORT'], bold: true);
  _row(sum, ['Report no.', o.reportNo]);
  if (o.revision.isNotEmpty) _row(sum, ['Revision', o.revision]);
  _row(sum, ['Project', pr.name]);
  if (pr.address.isNotEmpty) _row(sum, ['Location', pr.address]);
  if (pr.client.isNotEmpty) _row(sum, ['Client / Owner', pr.client]);
  _row(sum, ['Prepared by', o.preparedBy]);
  if (st.license.isNotEmpty) _row(sum, ['Licence no.', st.license]);
  if (o.company.isNotEmpty) _row(sum, ['Company', o.company]);
  _row(sum, ['Report date', _d(now)]);
  if (o.periodText.isNotEmpty) _row(sum, ['Period', o.periodText]);
  final overall = overallPercent(pr);
  _row(sum, ['Overall progress %', overall]);
  final variance = scheduleVariance(pr);
  if (variance != null) _row(sum, ['Schedule', varianceText(variance)]);
  _row(sum, []);
  _row(sum, ['OVERALL PROJECT PROGRESS'], bold: true);
  _row(sum, ['Date', 'Progress %', 'Note'], bold: true);
  if (pr.weighted) {
    for (final pt in actualSeries(pr).where((x) => o.inRange(x.date))) {
      _row(sum, [_d(pt.date), pt.pct, 'Calculated from weighted trades']);
    }
  } else {
    for (final e in sortedEntries(pr.progress).where((e) => o.inRange(e.date))) {
      _row(sum, [_d(e.date), e.percent, e.note]);
    }
  }
  if (pr.planned.isNotEmpty) {
    _row(sum, []);
    _row(sum, ['PLANNED (S-CURVE)'], bold: true);
    _row(sum, ['Date', 'Planned %'], bold: true);
    for (final e in sortedEntries(pr.planned)) {
      _row(sum, [_d(e.date), e.percent]);
    }
  }
  _row(sum, []);
  _row(sum, ['TRADE SUMMARY'], bold: true);
  _row(sum, ['Trade', 'Latest progress %', 'As of', 'Inspections', 'Weight'], bold: true);
  for (final t in pr.trades) {
    final l = latestEntry(t.progress);
    _row(sum, [t.name, l?.percent, l == null ? '' : _d(l.date), t.inspections.where((i) => o.inRange(i.date)).length, t.weight]);
  }

  // --------------------------------------------------------- trade progress
  final tp = ex['Trade Progress'];
  _widths(tp, [26, 14, 12, 40]);
  _row(tp, ['Trade', 'Date', 'Progress %', 'Note'], bold: true);
  for (final t in pr.trades) {
    for (final e in sortedEntries(t.progress).where((e) => o.inRange(e.date))) {
      _row(tp, [t.name, _d(e.date), e.percent, e.note]);
    }
  }

  // ------------------------------------------------------------ inspections
  final insp = ex['Inspections'];
  _widths(insp, [26, 14, 16, 24, 16, 24, 50, 8, 14, 22, 22]);
  _row(insp, ['Trade', 'Date', 'Status', 'Inspector', 'Role', 'Company', 'Notes', 'Photos', 'Checklist pass/total', 'Contractor', 'Client'], bold: true);
  for (final t in pr.trades) {
    final list = t.inspections.where((i) => o.inRange(i.date)).toList()..sort((a, b) => a.date.compareTo(b.date));
    for (final i in list) {
      final pass = i.checklist.where((c) => c.result == 'Pass').length;
      _row(insp, [
        t.name,
        _d(i.date),
        i.status,
        i.inspectorName,
        i.role,
        i.company,
        i.notes,
        i.photos.length,
        i.checklist.isEmpty ? '' : '$pass/${i.checklist.length}',
        i.sigContractor.name,
        i.sigClient.name,
      ]);
    }
  }

  // -------------------------------------------------------------- checklists
  final cl = ex['Checklists'];
  _widths(cl, [26, 14, 50, 10, 40]);
  _row(cl, ['Trade', 'Inspection date', 'Item', 'Result', 'Remark'], bold: true);
  for (final t in pr.trades) {
    for (final i in t.inspections.where((i) => o.inRange(i.date))) {
      for (final c in i.checklist) {
        _row(cl, [t.name, _d(i.date), c.text, c.result.isEmpty ? '-' : c.result, c.remark]);
      }
    }
  }

  // -------------------------------------------------------------- punch list
  final pl = ex['Punch List'];
  _widths(pl, [10, 30, 40, 22, 18, 22, 14, 12, 14, 22, 8]);
  _row(pl, ['No.', 'Title', 'Description', 'Location', 'Trade', 'Responsible', 'Due', 'Status', 'Logged', 'Keyplan', 'Pin'], bold: true);
  final defects = pr.defects.where((d) => o.inRange(d.createdAt)).toList()..sort((a, b) => a.no.compareTo(b.no));
  for (final d in defects) {
    var kpName = '';
    for (final k in pr.keyplans) {
      if (k.id == d.keyplanId) kpName = k.name;
    }
    _row(pl, [
      d.no,
      d.title,
      d.desc,
      d.location,
      d.trade,
      d.responsible,
      d.due == null ? '' : _d(d.due!),
      d.status,
      _d(d.createdAt),
      kpName,
      d.pin,
    ]);
  }

  // --------------------------------------------------------------- site log
  final sl = ex['Site Log'];
  _widths(sl, [14, 18, 8, 12, 40, 30, 30, 30]);
  _row(sl, ['Date', 'Weather', 'Temp C', 'Manpower', 'Manpower detail', 'Equipment', 'Delays', 'Notes'], bold: true);
  final logs = pr.logs.where((l) => o.inRange(l.date)).toList()..sort((a, b) => a.date.compareTo(b.date));
  for (final l in logs) {
    _row(sl, [
      _d(l.date),
      l.weather,
      l.temp,
      l.totalManpower,
      l.manpower.map((m) => '${m.label} x${m.count}').join('; '),
      l.equipment,
      l.delays,
      l.notes,
    ]);
  }

  // ----------------------------------------------------------------- photos
  if (o.photos) {
    final ph = ex['Photos'];
    _widths(ph, [26, 14, 30, 22, 36, 12, 12, 10]);
    _row(ph, ['Trade', 'Inspection date', 'Caption', 'Taken', 'Address', 'Latitude', 'Longitude', 'Source'], bold: true);
    for (final t in pr.trades) {
      for (final i in t.inspections.where((i) => o.inRange(i.date))) {
        for (final x in i.photos) {
          _row(ph, [
            t.name,
            _d(i.date),
            x.caption,
            x.takenAt == null ? '' : _dt(x.takenAt!),
            x.address,
            x.lat,
            x.lng,
            x.fromGallery ? 'Gallery' : 'Camera',
          ]);
        }
      }
    }
  }

  final bytes = ex.save();
  final tmp = await getTemporaryDirectory();
  final out = File(p.join(tmp.path, '${safeFileName(pr.name)}_report_${DateFormat('yyyyMMdd').format(now)}.xlsx'));
  await out.writeAsBytes(bytes!);
  return out;
}
