import 'package:intl/intl.dart';

import '../calc.dart';

class ReportOptions {
  ReportOptions({
    required this.name,
    required this.role,
    required this.company,
    required this.reportNo,
    this.revision = '',
    this.photos = true,
    this.keyplans = true,
    this.from,
    this.to,
  });

  final String name;
  final String role;
  final String company;
  final String reportNo;
  final String revision;
  final bool photos;
  final bool keyplans;
  final DateTime? from;
  final DateTime? to;

  String get preparedBy => [
        if (name.isNotEmpty) name,
        if (role.isNotEmpty) role,
      ].join(', ');

  bool inRange(DateTime d) {
    final x = dateOnly(d);
    if (from != null && x.isBefore(dateOnly(from!))) return false;
    if (to != null && x.isAfter(dateOnly(to!))) return false;
    return true;
  }

  String get periodText {
    if (from == null && to == null) return '';
    final f = DateFormat('dd MMM yyyy');
    return '${from == null ? 'Start' : f.format(from!)} to ${to == null ? 'Present' : f.format(to!)}';
  }
}

String safeFileName(String s) {
  final t = s.trim().replaceAll(RegExp(r'[^A-Za-z0-9_\- ]'), '').replaceAll(RegExp(r'\s+'), '_');
  return t.isEmpty ? 'project' : t;
}
