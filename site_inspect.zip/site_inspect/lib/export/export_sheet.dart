import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../screens/inspection_screen.dart' show kRoles;
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'excel_export.dart';
import 'pdf_export.dart';
import 'report_options.dart';

Future<void> showExportSheet(BuildContext context, Project project) async {
  final st = Store.i.settings;
  final name = TextEditingController(text: st.lastName);
  final company = TextEditingController(text: st.lastCompany);
  final reportNo = TextEditingController(
    text: 'RPT-${DateTime.now().year}-${(project.reportSeq + 1).toString().padLeft(3, '0')}',
  );
  final rev = TextEditingController();
  var role = st.lastRole;
  var photos = true;
  var keyplans = true;
  DateTime? from;
  DateTime? to;

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kBlueDark,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) {
        Future<void> pickDate(bool isFrom) async {
          final d = await showDatePicker(
            context: ctx,
            initialDate: (isFrom ? from : to) ?? DateTime.now(),
            firstDate: DateTime(2000),
            lastDate: DateTime(2100),
          );
          if (d != null) setS(() => isFrom ? from = d : to = d);
        }

        Future<void> run(bool pdf) async {
          st
            ..lastName = name.text.trim()
            ..lastRole = role
            ..lastCompany = company.text.trim();
          Store.i.saveSoon();
          final o = ReportOptions(
            name: name.text.trim(),
            role: role,
            company: company.text.trim(),
            reportNo: reportNo.text.trim(),
            revision: rev.text.trim(),
            photos: photos,
            keyplans: keyplans,
            from: from,
            to: to,
          );
          try {
            final File f = await runWithLoader<File>(
              ctx,
              pdf ? 'Building PDF report…' : 'Building Excel report…',
              () => pdf ? buildPdf(project, o) : buildExcel(project, o),
            );
            project.reportSeq += 1;
            Store.i.saveSoon();
            if (ctx.mounted) Navigator.pop(ctx);
            await Share.shareXFiles([XFile(f.path)], subject: '${project.name} inspection report');
          } catch (e) {
            if (ctx.mounted) toast(ctx, 'Could not build the report: $e');
          }
        }

        return Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('GENERATE REPORT', style: TextStyle(fontFamily: kMono, fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(flex: 3, child: TextField(controller: reportNo, decoration: deco('Report no.'))),
                    const SizedBox(width: 8),
                    Expanded(flex: 2, child: TextField(controller: rev, decoration: deco('Revision', hint: 'A'))),
                  ],
                ),
                const SizedBox(height: 12),
                const BpLabel('Prepared by (shown on report cover)'),
                TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: deco('Full name')),
                const SizedBox(height: 10),
                ChipPicker(
                  presets: kRoles,
                  value: role,
                  customHint: 'Type your role / title',
                  onChanged: (v) => role = v,
                ),
                const SizedBox(height: 10),
                TextField(controller: company, textCapitalization: TextCapitalization.words, decoration: deco('Company')),
                const SizedBox(height: 12),
                const BpLabel('Period (optional, leave empty for everything)'),
                Row(
                  children: [
                    Expanded(child: OutlinedButton(onPressed: () => pickDate(true), child: Text(from == null ? 'From' : fmtDate(from!)))),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton(onPressed: () => pickDate(false), child: Text(to == null ? 'To' : fmtDate(to!)))),
                    if (from != null || to != null)
                      IconButton(
                        onPressed: () => setS(() {
                          from = null;
                          to = null;
                        }),
                        icon: const Icon(Icons.clear),
                      ),
                  ],
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Include photos'),
                  value: photos,
                  onChanged: (v) => setS(() => photos = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Include marked-up keyplans (PDF only)'),
                  value: keyplans,
                  onChanged: (v) => setS(() => keyplans = v),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => run(true),
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text('PDF'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => run(false),
                        icon: const Icon(Icons.table_chart),
                        label: const Text('EXCEL'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
