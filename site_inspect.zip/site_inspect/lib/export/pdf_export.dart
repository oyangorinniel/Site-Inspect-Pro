import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../calc.dart';
import '../markup_painter.dart';
import '../models.dart';
import '../scurve.dart';
import '../store.dart';
import 'report_options.dart';

// Default PDF fonts are Latin-1 only; replace anything else so text never vanishes.
String _s(String t) => t.replaceAll(RegExp(r'[^\x00-\xFF]'), '?');

String _pct(double v) => '${v.toStringAsFixed(v % 1 == 0 ? 0 : 1)}%';
String _d(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String _dt(DateTime d) => DateFormat('dd MMM yyyy, hh:mm a').format(d);

Uint8List _shrinkJob(Map<String, dynamic> a) {
  final bytes = a['bytes'] as Uint8List;
  final maxSide = a['max'] as int;
  final im = img.decodeImage(bytes);
  if (im == null) return bytes;
  final up = img.bakeOrientation(im);
  final r = up.width >= up.height
      ? img.copyResize(up, width: min(maxSide, up.width))
      : img.copyResize(up, height: min(maxSide, up.height));
  return Uint8List.fromList(img.encodeJpg(r, quality: 78));
}

Future<Uint8List> _photoBytes(PhotoItem ph) async {
  final path = Store.i.mediaPath(ph.file);
  if (ph.markups.isNotEmpty) {
    final png = await renderKeyplanPng(path, ph.markups, maxW: 1100);
    if (png != null) return png;
  }
  return compute(_shrinkJob, {'bytes': await File(path).readAsBytes(), 'max': 1100});
}

const _grid = PdfColors.grey500;

Future<File> buildPdf(Project pr, ReportOptions o) async {
  final st = Store.i.settings;
  final accent = PdfColor.fromInt(st.accent);
  final now = DateTime.now();
  final doc = pw.Document(title: '${pr.name} - Inspection Progress Report', author: o.name);

  pw.MemoryImage? logo;
  if (st.logoFile != null) {
    final f = File(Store.i.mediaPath(st.logoFile!));
    if (await f.exists()) logo = pw.MemoryImage(await f.readAsBytes());
  }

  // ---------------------------------------------------------- small builders
  pw.Widget cell(String t, {bool bold = false}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: pw.Text(_s(t), style: pw.TextStyle(fontSize: 10, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
      );

  pw.Widget kv(List<List<String>> rows) => pw.Table(
        border: pw.TableBorder.all(color: _grid, width: 0.5),
        columnWidths: {0: const pw.FixedColumnWidth(110)},
        children: [
          for (final r in rows) pw.TableRow(children: [cell(r[0], bold: true), cell(r[1])]),
        ],
      );

  pw.Widget table(List<String> headers, List<List<String>> rows) => pw.TableHelper.fromTextArray(
        headers: headers,
        data: rows.map((r) => r.map(_s).toList()).toList(),
        headerStyle: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
        headerDecoration: pw.BoxDecoration(color: accent),
        cellStyle: const pw.TextStyle(fontSize: 10),
        cellAlignment: pw.Alignment.centerLeft,
        border: pw.TableBorder.all(color: _grid, width: 0.5),
        cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      );

  pw.Widget heading(String t) => pw.Text(
        _s(t),
        style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: accent),
      );

  pw.Widget bar(String t) => pw.Container(
        width: double.infinity,
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: const pw.BoxDecoration(color: PdfColors.grey300),
        child: pw.Text(_s(t.toUpperCase()), style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: accent)),
      );

  Future<pw.Widget> photoTile(PhotoItem ph, {String? label}) async {
    final small = await _photoBytes(ph);
    final meta = [
      if (ph.takenAt != null) _dt(ph.takenAt!),
      if (ph.lat != null && ph.lng != null) '${ph.lat!.toStringAsFixed(5)}, ${ph.lng!.toStringAsFixed(5)}',
    ].join('  |  ');
    return pw.Container(
      width: 255,
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          if (label != null) pw.Text(label, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: accent)),
          pw.Container(
            width: 255,
            height: 175,
            color: PdfColors.grey200,
            child: pw.Image(pw.MemoryImage(small), fit: pw.BoxFit.contain),
          ),
          pw.SizedBox(height: 2),
          if (ph.caption.isNotEmpty) pw.Text(_s(ph.caption), style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
          if (ph.address.isNotEmpty) pw.Text(_s(ph.address), style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
          if (meta.isNotEmpty) pw.Text(meta, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
          if (ph.lat != null && ph.lng != null)
            pw.UrlLink(
              destination: 'https://maps.google.com/?q=${ph.lat},${ph.lng}',
              child: pw.Text(
                'Open map',
                style: const pw.TextStyle(fontSize: 8, color: PdfColors.blue700, decoration: pw.TextDecoration.underline),
              ),
            ),
        ],
      ),
    );
  }

  Future<pw.Widget> sigBox(String label, SignBlock b, String fallbackName) async {
    pw.Widget sig = pw.SizedBox(height: 40);
    if (b.file != null) {
      final f = File(Store.i.mediaPath(b.file!));
      if (await f.exists()) {
        sig = pw.SizedBox(
          height: 40,
          child: pw.Image(pw.MemoryImage(await f.readAsBytes()), fit: pw.BoxFit.contain, alignment: pw.Alignment.centerLeft),
        );
      }
    }
    final name = b.name.isNotEmpty ? b.name : fallbackName;
    return pw.Expanded(
      child: pw.Container(
        margin: const pw.EdgeInsets.only(right: 8),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            sig,
            pw.Container(height: 0.8, color: PdfColors.grey700),
            pw.SizedBox(height: 2),
            pw.Text(_s(name), style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
            pw.Text(_s(label), style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
            if (b.date != null) pw.Text(_d(b.date!), style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
          ],
        ),
      ),
    );
  }

  final overall = overallPercent(pr);
  final overallAt = overallDate(pr);
  final variance = scheduleVariance(pr);
  final overallText = overall == null
      ? 'No entries'
      : '${_pct(overall)}${overallAt == null ? '' : ' (as of ${_d(overallAt)})'}';

  // ------------------------------------------------------------------ cover
  doc.addPage(pw.Page(
    pageTheme: pw.PageTheme(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(40)),
    build: (ctx) => pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        if (logo != null)
          pw.SizedBox(
            width: 140,
            height: 70,
            child: pw.Image(logo, fit: pw.BoxFit.contain, alignment: pw.Alignment.centerLeft),
          ),
        if (o.company.isNotEmpty) pw.Text(_s(o.company), style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
        if (st.contact.isNotEmpty) pw.Text(_s(st.contact), style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        pw.SizedBox(height: 60),
        pw.Container(
          width: double.infinity,
          color: accent,
          padding: const pw.EdgeInsets.all(16),
          child: pw.Text(
            'INSPECTION PROGRESS REPORT',
            style: pw.TextStyle(color: PdfColors.white, fontSize: 22, fontWeight: pw.FontWeight.bold),
          ),
        ),
        pw.SizedBox(height: 20),
        pw.Text(_s(pr.name), style: pw.TextStyle(fontSize: 26, fontWeight: pw.FontWeight.bold)),
        if (pr.address.isNotEmpty) pw.Text(_s(pr.address), style: const pw.TextStyle(fontSize: 12, color: PdfColors.grey700)),
        pw.SizedBox(height: 24),
        kv([
          ['Report no.', o.reportNo.isEmpty ? '-' : o.reportNo],
          if (o.revision.isNotEmpty) ['Revision', o.revision],
          ['Report date', _d(now)],
          if (o.periodText.isNotEmpty) ['Period', o.periodText],
          if (pr.client.isNotEmpty) ['Client / Owner', pr.client],
          ['Prepared by', o.preparedBy.isEmpty ? '-' : o.preparedBy],
          if (st.license.isNotEmpty) ['Licence no.', st.license],
          if (o.company.isNotEmpty) ['Company', o.company],
        ]),
        pw.Spacer(),
        pw.Text('OVERALL PROGRESS', style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: PdfColors.grey700)),
        pw.Text(_s(overallText), style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold, color: accent)),
        if (variance != null) pw.Text(varianceText(variance), style: const pw.TextStyle(fontSize: 11)),
      ],
    ),
  ));

  // ---------------------------------------------------------------- content
  final w = <pw.Widget>[];

  w.add(heading('Overall Project Progress'));
  w.add(pw.SizedBox(height: 4));
  w.add(pw.Text(
    _s('Current: $overallText${variance == null ? '' : '   |   ${varianceText(variance)}'}'),
    style: const pw.TextStyle(fontSize: 10),
  ));
  w.add(pw.SizedBox(height: 6));

  final planned = plannedSeries(pr);
  final actual = actualSeries(pr);
  if (planned.isNotEmpty || actual.length >= 2) {
    final sc = await renderSCurvePng(planned, actual);
    if (sc != null) {
      w.add(pw.Container(
        height: 190,
        width: double.infinity,
        child: pw.Image(pw.MemoryImage(sc), fit: pw.BoxFit.contain),
      ));
      w.add(pw.Text(
        'Dashed line = planned, solid line = actual.',
        style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
      ));
      w.add(pw.SizedBox(height: 6));
    }
  }

  if (pr.weighted) {
    w.add(pw.Text(
      'Overall progress is calculated from the trades using their weights.',
      style: const pw.TextStyle(fontSize: 10),
    ));
  } else {
    final rows = sortedEntries(pr.progress).where((e) => o.inRange(e.date)).map((e) => [_d(e.date), _pct(e.percent), e.note]).toList();
    w.add(rows.isEmpty
        ? pw.Text('No progress entries.', style: const pw.TextStyle(fontSize: 10))
        : table(['Date', 'Progress', 'Note'], rows));
  }
  w.add(pw.SizedBox(height: 10));

  if (pr.trades.isNotEmpty) {
    w.add(heading('Trade Summary'));
    w.add(pw.SizedBox(height: 4));
    w.add(table(
      ['Trade', if (pr.weighted) 'Weight', 'Latest progress', 'As of', 'Inspections'],
      [
        for (final t in pr.trades)
          [
            t.name,
            if (pr.weighted) t.weight.toStringAsFixed(t.weight % 1 == 0 ? 0 : 1),
            latestEntry(t.progress) == null ? '-' : _pct(latestEntry(t.progress)!.percent),
            latestEntry(t.progress) == null ? '-' : _d(latestEntry(t.progress)!.date),
            '${t.inspections.where((i) => o.inRange(i.date)).length}',
          ],
      ],
    ));
  }

  // ----------------------------------------------------------------- trades
  for (final t in pr.trades) {
    w.add(pw.SizedBox(height: 18));
    w.add(bar(t.name));
    w.add(pw.SizedBox(height: 6));
    final rows = sortedEntries(t.progress).where((e) => o.inRange(e.date)).map((e) => [_d(e.date), _pct(e.percent), e.note]).toList();
    if (rows.isNotEmpty) w.add(table(['Date', 'Progress', 'Note'], rows));

    final ins = t.inspections.where((i) => o.inRange(i.date)).toList()..sort((a, b) => a.date.compareTo(b.date));
    for (final i in ins) {
      w.add(pw.SizedBox(height: 10));
      w.add(pw.Text(
        _s('Inspection ${_d(i.date)}  -  Status: ${i.status}'),
        style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold),
      ));
      final by = [
        if (i.inspectorName.isNotEmpty) i.inspectorName,
        if (i.role.isNotEmpty) i.role,
        if (i.company.isNotEmpty) i.company,
      ].join(', ');
      if (by.isNotEmpty) {
        w.add(pw.Text(_s('Inspected by: $by'), style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)));
      }
      if (i.notes.trim().isNotEmpty) {
        w.add(pw.SizedBox(height: 3));
        w.add(pw.Text(_s(i.notes.trim()), style: const pw.TextStyle(fontSize: 10)));
      }
      if (i.checklist.isNotEmpty) {
        w.add(pw.SizedBox(height: 5));
        w.add(table(
          ['Checklist item', 'Result', 'Remark'],
          [
            for (final c in i.checklist) [c.text, c.result.isEmpty ? '-' : c.result, c.remark],
          ],
        ));
      }
      if (o.photos && i.photos.isNotEmpty) {
        w.add(pw.SizedBox(height: 6));
        final tiles = <pw.Widget>[];
        for (final ph in i.photos) {
          if (!await File(Store.i.mediaPath(ph.file)).exists()) continue;
          tiles.add(await photoTile(ph));
        }
        if (tiles.isNotEmpty) w.add(pw.Wrap(spacing: 8, runSpacing: 8, children: tiles));
      }
      final hasSig = [i.sigInspector, i.sigContractor, i.sigClient].any((b) => b.file != null || b.name.isNotEmpty);
      if (hasSig) {
        final boxes = <pw.Widget>[
          await sigBox(i.role.isEmpty ? 'Inspector' : i.role, i.sigInspector, i.inspectorName),
          await sigBox('Contractor', i.sigContractor, ''),
          await sigBox('Client', i.sigClient, ''),
        ];
        w.add(pw.SizedBox(height: 8));
        w.add(pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: boxes));
      }
    }
  }

  // -------------------------------------------------------------- punch list
  final defects = pr.defects.where((d) => o.inRange(d.createdAt)).toList()..sort((a, b) => a.no.compareTo(b.no));
  if (defects.isNotEmpty) {
    w.add(pw.SizedBox(height: 18));
    w.add(bar('Punch list'));
    w.add(pw.SizedBox(height: 4));
    int count(String s) => defects.where((d) => d.status == s).length;
    w.add(pw.Text(
      'Open: ${count('Open')}   Fixed: ${count('Fixed')}   Verified: ${count('Verified')}   Total: ${defects.length}',
      style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
    ));
    w.add(pw.SizedBox(height: 4));
    w.add(table(
      ['No.', 'Title', 'Location', 'Responsible', 'Due', 'Status'],
      [
        for (final d in defects)
          [d.no, d.title, d.location, d.responsible, d.due == null ? '-' : _d(d.due!), d.status],
      ],
    ));
    for (final d in defects) {
      Keyplan? kp;
      for (final k in pr.keyplans) {
        if (k.id == d.keyplanId) kp = k;
      }
      final hasDetail = d.desc.trim().isNotEmpty || d.before != null || d.after != null || kp != null;
      if (!hasDetail) continue;
      w.add(pw.SizedBox(height: 10));
      w.add(pw.Text(_s('${d.no}  ${d.title}  -  ${d.status}'), style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)));
      if (d.desc.trim().isNotEmpty) w.add(pw.Text(_s(d.desc.trim()), style: const pw.TextStyle(fontSize: 10)));
      if (kp != null) {
        w.add(pw.Text(
          _s('Keyplan: ${kp.name}${d.pin == null ? '' : ', pin #${d.pin}'}'),
          style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
        ));
      }
      final tiles = <pw.Widget>[];
      if (o.photos && d.before != null && await File(Store.i.mediaPath(d.before!.file)).exists()) {
        tiles.add(await photoTile(d.before!, label: 'BEFORE'));
      }
      if (o.photos && d.after != null && await File(Store.i.mediaPath(d.after!.file)).exists()) {
        tiles.add(await photoTile(d.after!, label: 'AFTER'));
      }
      if (tiles.isNotEmpty) {
        w.add(pw.SizedBox(height: 4));
        w.add(pw.Wrap(spacing: 8, runSpacing: 8, children: tiles));
      }
    }
  }

  // --------------------------------------------------------------- site logs
  final logs = pr.logs.where((l) => o.inRange(l.date)).toList()..sort((a, b) => a.date.compareTo(b.date));
  if (logs.isNotEmpty) {
    w.add(pw.SizedBox(height: 18));
    w.add(bar('Daily site logs'));
    for (final l in logs) {
      w.add(pw.SizedBox(height: 8));
      w.add(pw.Text(
        _s('${_d(l.date)}${l.weather.isEmpty ? '' : '  -  ${l.weather}'}${l.temp.isEmpty ? '' : ', ${l.temp} C'}'),
        style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold),
      ));
      if (l.manpower.isNotEmpty) {
        w.add(pw.SizedBox(height: 3));
        w.add(table(
          ['Manpower', 'Count'],
          [
            for (final m in l.manpower) [m.label, '${m.count}'],
            ['Total', '${l.totalManpower}'],
          ],
        ));
      }
      if (l.equipment.trim().isNotEmpty) {
        w.add(pw.Text(_s('Equipment: ${l.equipment.trim()}'), style: const pw.TextStyle(fontSize: 10)));
      }
      if (l.delays.trim().isNotEmpty) {
        w.add(pw.Text(_s('Delays / issues: ${l.delays.trim()}'), style: const pw.TextStyle(fontSize: 10)));
      }
      if (l.notes.trim().isNotEmpty) {
        w.add(pw.Text(_s('Notes: ${l.notes.trim()}'), style: const pw.TextStyle(fontSize: 10)));
      }
    }
  }

  doc.addPage(pw.MultiPage(
    pageTheme: const pw.PageTheme(pageFormat: PdfPageFormat.a4, margin: pw.EdgeInsets.all(32)),
    header: (ctx) => pw.Container(
      padding: const pw.EdgeInsets.only(bottom: 4),
      margin: const pw.EdgeInsets.only(bottom: 8),
      decoration: pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: accent, width: 1))),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Row(
            children: [
              if (logo != null) pw.SizedBox(width: 44, height: 24, child: pw.Image(logo, fit: pw.BoxFit.contain)),
              if (logo != null) pw.SizedBox(width: 6),
              pw.Text(_s(o.company.isEmpty ? pr.name : o.company), style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
            ],
          ),
          pw.Text(
            _s('${o.reportNo}${o.revision.isEmpty ? '' : '  Rev ${o.revision}'}'),
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
        ],
      ),
    ),
    footer: (ctx) => pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(_s(st.footer.isEmpty ? pr.name : st.footer), style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
        pw.Text('Page ${ctx.pageNumber} of ${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
      ],
    ),
    build: (ctx) => w,
  ));

  // --------------------------------------------------------------- keyplans
  if (o.keyplans) {
    for (final k in pr.keyplans) {
      final png = await renderKeyplanPng(Store.i.mediaPath(k.file), k.markups);
      if (png == null) continue;
      final mi = pw.MemoryImage(png);
      final landscape = (mi.width ?? 1) >= (mi.height ?? 1);
      doc.addPage(pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: landscape ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(28),
        ),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(_s('Keyplan: ${k.name}'), style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: accent)),
            pw.SizedBox(height: 6),
            pw.Expanded(child: pw.Center(child: pw.Image(mi, fit: pw.BoxFit.contain))),
          ],
        ),
      ));
    }
  }

  final tmp = await getTemporaryDirectory();
  final out = File(p.join(tmp.path, '${safeFileName(pr.name)}_report_${DateFormat('yyyyMMdd').format(now)}.pdf'));
  await out.writeAsBytes(await doc.save());
  return out;
}
