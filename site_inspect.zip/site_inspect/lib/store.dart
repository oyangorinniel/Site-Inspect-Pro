import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// Offline-first storage: one JSON file plus a media folder, all in the app's
/// private documents directory.
class Store extends ChangeNotifier {
  Store._();
  static final Store i = Store._();

  late Directory media;
  late File _file;
  List<Project> projects = [];
  List<ChecklistTemplate> templates = defaultTemplates();
  AppSettings settings = AppSettings();
  Timer? _timer;

  Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    media = Directory(p.join(docs.path, 'inspect_media'));
    if (!media.existsSync()) media.createSync(recursive: true);
    _file = File(p.join(docs.path, 'inspect_data.json'));
    if (_file.existsSync()) {
      try {
        _load(jsonDecode(await _file.readAsString()) as Map<String, dynamic>);
      } catch (_) {
        await _file.copy('${_file.path}.corrupt');
      }
    }
  }

  void _load(Map<String, dynamic> j) {
    projects = ((j['projects'] ?? []) as List)
        .map((e) => Project.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    settings = AppSettings.fromJson(Map<String, dynamic>.from(j['settings'] ?? {}));
    if (j['templates'] != null) {
      templates = ((j['templates']) as List)
          .map((e) => ChecklistTemplate.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    }
  }

  Map<String, dynamic> _toJson() => {
        'version': 1,
        'projects': projects.map((e) => e.toJson()).toList(),
        'settings': settings.toJson(),
        'templates': templates.map((e) => e.toJson()).toList(),
      };

  Future<void> save() async {
    _timer?.cancel();
    final tmp = File('${_file.path}.tmp');
    await tmp.writeAsString(jsonEncode(_toJson()), flush: true);
    await tmp.rename(_file.path);
    notifyListeners();
  }

  void saveSoon() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 500), save);
  }

  String mediaPath(String name) => p.join(media.path, name);

  Future<String> addMediaBytes(List<int> bytes, String ext) async {
    final name = '${newId()}.$ext';
    await File(mediaPath(name)).writeAsBytes(bytes, flush: true);
    return name;
  }

  Future<void> deleteMedia(String name) async {
    final f = File(mediaPath(name));
    if (await f.exists()) await f.delete();
  }

  Future<void> deleteProject(Project pr) async {
    for (final f in pr.mediaFiles.toList()) {
      await deleteMedia(f);
    }
    projects.remove(pr);
    await save();
  }

  // ---------------------------------------------------------------- backup
  // Single-file backup: "SIB1" + header length + header JSON + raw media bytes.

  Future<File> exportBackup() async {
    settings.lastBackup = DateTime.now();
    await save();
    final tmp = await getTemporaryDirectory();
    final stamp = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
    final out = File(p.join(tmp.path, 'SiteInspect_backup_$stamp.sibackup'));
    final files = media.listSync().whereType<File>().toList();
    final header = utf8.encode(jsonEncode({
      'data': jsonEncode(_toJson()),
      'files': [
        for (final f in files) {'name': p.basename(f.path), 'len': f.lengthSync()}
      ],
    }));
    final sink = out.openWrite();
    sink.add(utf8.encode('SIB1'));
    final len = ByteData(4)..setUint32(0, header.length);
    sink.add(len.buffer.asUint8List());
    sink.add(header);
    for (final f in files) {
      await sink.addStream(f.openRead());
    }
    await sink.close();
    return out;
  }

  /// Replaces all current data with the backup. Returns false if the file is
  /// not a valid backup.
  Future<bool> restoreBackup(File f) async {
    final raf = await f.open();
    try {
      final magic = await raf.read(4);
      if (utf8.decode(magic, allowMalformed: true) != 'SIB1') return false;
      final lb = await raf.read(4);
      final hlen = ByteData.sublistView(lb).getUint32(0);
      final header = jsonDecode(utf8.decode(await raf.read(hlen))) as Map<String, dynamic>;
      for (final fi in (header['files'] as List)) {
        final name = p.basename(fi['name'] as String);
        var remaining = fi['len'] as int;
        final w = File(mediaPath(name)).openWrite();
        while (remaining > 0) {
          final chunk = await raf.read(min(remaining, 1 << 20));
          if (chunk.isEmpty) break;
          w.add(chunk);
          remaining -= chunk.length;
        }
        await w.close();
      }
      _load(jsonDecode(header['data'] as String) as Map<String, dynamic>);
      await save();
      return true;
    } catch (_) {
      return false;
    } finally {
      await raf.close();
    }
  }
}
