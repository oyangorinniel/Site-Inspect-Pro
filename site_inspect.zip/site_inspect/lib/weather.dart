import 'dart:convert';

import 'package:http/http.dart' as http;

String _wmo(int c) {
  if (c == 0) return 'Sunny / clear';
  if (c <= 2) return 'Partly cloudy';
  if (c == 3) return 'Cloudy';
  if (c == 45 || c == 48) return 'Fog';
  if (c >= 51 && c <= 57) return 'Drizzle';
  if (c >= 61 && c <= 67) return 'Rain';
  if (c >= 71 && c <= 77) return 'Snow';
  if (c >= 80 && c <= 82) return 'Rain showers';
  if (c >= 95) return 'Thunderstorm';
  return 'Cloudy';
}

/// Current weather from the free Open-Meteo service (no key needed).
Future<({String text, double temp})?> fetchWeather(double lat, double lng) async {
  try {
    final uri = Uri.parse(
      'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng&current=temperature_2m,weather_code',
    );
    final r = await http.get(uri).timeout(const Duration(seconds: 8));
    if (r.statusCode != 200) return null;
    final cur = (jsonDecode(r.body) as Map)['current'] as Map;
    return (
      text: _wmo((cur['weather_code'] as num).toInt()),
      temp: (cur['temperature_2m'] as num).toDouble(),
    );
  } catch (_) {
    return null;
  }
}
