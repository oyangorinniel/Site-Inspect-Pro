import 'models.dart';

class Pt {
  const Pt(this.date, this.pct);
  final DateTime date;
  final double pct;
}

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

double tradeLatest(Trade t) => latestEntry(t.progress)?.percent ?? 0;

bool _anyTradeProgress(Project p) => p.trades.any((t) => t.progress.isNotEmpty);

/// Overall percentage: weighted average of the trades when the project is set
/// to "weighted", otherwise the latest manually entered value.
double? overallPercent(Project p) {
  if (p.weighted && p.trades.isNotEmpty) {
    if (!_anyTradeProgress(p)) return null;
    var sw = 0.0;
    var s = 0.0;
    for (final t in p.trades) {
      sw += t.weight;
      s += t.weight * tradeLatest(t);
    }
    return sw <= 0 ? null : s / sw;
  }
  return latestEntry(p.progress)?.percent;
}

DateTime? overallDate(Project p) {
  if (p.weighted && p.trades.isNotEmpty) {
    DateTime? best;
    for (final t in p.trades) {
      final e = latestEntry(t.progress);
      if (e != null && (best == null || e.date.isAfter(best))) best = e.date;
    }
    return best;
  }
  return latestEntry(p.progress)?.date;
}

/// Actual progress over time (for the S-curve).
List<Pt> actualSeries(Project p) {
  if (p.weighted && p.trades.isNotEmpty) {
    final dates = <DateTime>{};
    for (final t in p.trades) {
      for (final e in t.progress) {
        dates.add(dateOnly(e.date));
      }
    }
    final sorted = dates.toList()..sort();
    final out = <Pt>[];
    for (final d in sorted) {
      var sw = 0.0;
      var s = 0.0;
      for (final t in p.trades) {
        var v = 0.0;
        DateTime? bd;
        for (final e in t.progress) {
          final ed = dateOnly(e.date);
          if (!ed.isAfter(d) && (bd == null || !ed.isBefore(bd))) {
            bd = ed;
            v = e.percent;
          }
        }
        sw += t.weight;
        s += t.weight * v;
      }
      out.add(Pt(d, sw <= 0 ? 0 : s / sw));
    }
    return out;
  }
  return sortedEntries(p.progress).map((e) => Pt(dateOnly(e.date), e.percent)).toList();
}

List<Pt> plannedSeries(Project p) =>
    sortedEntries(p.planned).map((e) => Pt(dateOnly(e.date), e.percent)).toList();

/// Planned percentage on a date, interpolated between planned points.
double? plannedAt(Project p, DateTime d) {
  final pl = plannedSeries(p);
  if (pl.isEmpty) return null;
  final day = dateOnly(d);
  if (!day.isAfter(pl.first.date)) return pl.first.pct;
  if (!day.isBefore(pl.last.date)) return pl.last.pct;
  for (var i = 1; i < pl.length; i++) {
    final a = pl[i - 1];
    final b = pl[i];
    if (!day.isAfter(b.date)) {
      final span = b.date.difference(a.date).inDays;
      if (span <= 0) return b.pct;
      final t = day.difference(a.date).inDays / span;
      return a.pct + (b.pct - a.pct) * t;
    }
  }
  return pl.last.pct;
}

/// Actual minus planned at the latest actual date (positive = ahead).
double? scheduleVariance(Project p) {
  final o = overallPercent(p);
  if (o == null) return null;
  final pl = plannedAt(p, overallDate(p) ?? DateTime.now());
  if (pl == null) return null;
  return o - pl;
}

String varianceText(double v) {
  if (v.abs() < 0.5) return 'On schedule';
  return v > 0 ? 'Ahead by ${v.toStringAsFixed(1)}%' : 'Behind by ${(-v).toStringAsFixed(1)}%';
}
